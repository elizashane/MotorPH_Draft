MotorPH Payroll Management System
Project Documentation

Team Information + Repository Link

Repository Link
[Insert Git repository link here]

Example format:
https://github.com/organization/motorph-payroll-system

Team Members
Member 1
Member 2
Member 3

Note
All team members must be listed here. If a member is not included in this section, it will be assumed that the member did not contribute to the project.

Refactoring Plan

Overview

The MotorPH Payroll Management System was originally based on procedural code from CP2. The system was refactored into an object oriented design in order to improve modularity, maintainability, and scalability. The refactoring process separated the application into multiple layers including Model, DAO, Service, and UI components.

GUI classes are excluded from the refactoring documentation as specified in the project requirements.

Model Classes

Person
Methods
getFirstName()
setFirstName(String)
getLastName()
setLastName(String)
getEmail()
setEmail(String)
getFullName()

User
Methods
getUsername()
setUsername(String)
getPassword()
setPassword(String)
getRole()
setRole(Role)
getEmployeeNumber()
setEmployeeNumber(String)

Employee (extends Person, implements Payable)
Methods
getEmployeeNumber()
setEmployeeNumber(String)
getPosition()
setPosition(String)
getDepartment()
setDepartment(String)
getBasicSalary()
setBasicSalary(double)
getAllowance()
setAllowance(double)
getSss()
setSss(String)
getTin()
setTin(String)
getPagibig()
setPagibig(String)
getPhilhealth()
setPhilhealth(String)
getBirthday()
setBirthday(String)
getAddress()
setAddress(String)
getPhoneNumber()
setPhoneNumber(String)
getStatus()
setStatus(String)
calculateGrossSalary()
calculateNetSalary()

AttendanceRecord
Methods
getEmployeeNumber()
setEmployeeNumber(String)
getDate()
setDate(String)
getTimeIn()
setTimeIn(String)
getTimeOut()
setTimeOut(String)

LeaveRequest
Methods
getRequestId()
setRequestId(String)
getEmployeeNumber()
setEmployeeNumber(String)
getLeaveType()
setLeaveType(String)
getStartDate()
setStartDate(String)
getEndDate()
setEndDate(String)
getStatus()
setStatus(String)

PayrollRecord
Methods
getPayrollId()
setPayrollId(String)
getEmployeeNumber()
setEmployeeNumber(String)
getPeriodStart()
setPeriodStart(String)
getPeriodEnd()
setPeriodEnd(String)
getBasicSalary()
setBasicSalary(double)
getAllowance()
setAllowance(double)
getGrossSalary()
setGrossSalary(double)
getTax()
setTax(double)
getSss()
setSss(double)
getPhilhealth()
setPhilhealth(double)
getPagibig()
setPagibig(double)
getTotalDeductions()
setTotalDeductions(double)
getNetSalary()
setNetSalary(double)

DAO Classes

CSVHandler
Methods
readCSV(String filePath)
writeCSV(String filePath, List<String[]> rows)
appendRow(String filePath, String[] row)

EmployeeDAO
Methods
getAllEmployees()
findEmployee(String employeeNumber)
findByEmployeeNumber(String employeeNumber)
addEmployee(Employee employee)
updateEmployee(Employee employee)
deleteEmployee(String employeeNumber)

PayrollDAO
Methods
savePayroll(PayrollRecord record)
getPayrollByEmployee(String employeeNumber)
getLatestPayroll(String employeeNumber)

AttendanceDAO
Methods
getAttendanceRecords(String employeeNumber)
addTimeIn(String employeeNumber)
addTimeOut(String employeeNumber)

LeaveDAO
Methods
getLeaveRequests(String employeeNumber)
submitLeaveRequest(LeaveRequest request)

PasswordResetDAO
Methods
createResetRequest(String username)
getResetRequests()

Service Classes

AuthService
Methods
login(String username, String password)
requestPasswordReset(String username)

EmployeeService
Methods
findEmployee(String employeeNumber)
addEmployee(Employee employee)
updateEmployee(Employee employee)
deleteEmployee(String employeeNumber)

PayrollService
Methods
processPayroll(Employee employee)
getLatestPayroll(String employeeNumber)
calculateTax(double grossSalary)
calculateSSS(double grossSalary)
calculatePhilHealth(double grossSalary)
calculatePagibig(double grossSalary)

AttendanceService
Methods
timeIn(String employeeNumber)
timeOut(String employeeNumber)
getAttendanceHistory(String employeeNumber)

LeaveService
Methods
submitLeaveRequest(LeaveRequest request)
getLeaveHistory(String employeeNumber)

PasswordResetService
Methods
requestPasswordReset(String username)
getAllRequests()

SystemToolsService
Methods
getSystemStatus()
countRecords(String fileName)

RBACService
Methods
hasAccess(Role role, String module)

Explanation of Refactoring from CP2 to OOP

The CP2 implementation relied on procedural logic and centralized functions for handling payroll calculations, employee management, and attendance tracking. This approach resulted in tightly coupled code and limited scalability.

The CP3 implementation refactored the system into an object oriented architecture.

Key refactoring improvements include:

Encapsulation
Data and behavior are grouped within classes such as Employee, PayrollRecord, and AttendanceRecord.

Separation of Concerns
The application was divided into layers including Model, DAO, Service, and UI.

DAO Pattern
Data access logic was separated from business logic using DAO classes that handle CSV file operations.

Service Layer
Business rules and processing logic were moved into service classes such as PayrollService and EmployeeService.

Role Based Access Control
User roles are managed using Role enumeration and RBACService to control access to system modules.

This structure improves code organization, readability, and maintainability.

Smoke Test Checklist

The following smoke tests were conducted to verify that major system functions are working correctly.

Login System
Users can log in using valid credentials.
Invalid credentials generate an error message.
Show password toggle functions correctly.

Dashboard
Dashboard loads successfully after login.
Modules displayed depend on the user's role.

Employee Management
Employee records load from Employee.csv.
Employees can be added successfully.
Employee records can be updated.
Employee records can be deleted.

Payroll Processing
Payroll calculations run successfully.
Gross salary is calculated correctly.
Tax, SSS, PhilHealth, and Pag-IBIG deductions are applied.
Net salary is calculated correctly.

Payslip Generation
Payslip window opens successfully.
Employee payroll information displays correctly.

Attendance System
Employees can record Time In.
Employees can record Time Out.
Attendance entries are saved to TimeTracker.csv.

Leave Request System
Employees can submit leave requests.
Leave requests are saved to LeaveRequests.csv.
Leave balances are read from LeaveBalances.csv.

Password Reset System
Forgot password creates a reset request.
Requests are stored in Password_Reset_Requests.csv.
IT and Admin users can view reset requests.

System Tools
System tools module opens successfully.
System information and file status can be viewed.

Known Issues List

Issue 1
Payroll values may appear incorrect if incorrect CSV columns are read.

Resolution
Column mapping between Salary.csv and Allowance.csv was corrected.

Issue 2
Supervisor names in Employee.csv may appear as LastName FirstName.

Resolution
Supervisor names are formatted into FirstName LastName before display.

Issue 3
CSV files do not enforce strict validation rules.

Resolution
Basic validation checks were implemented to prevent malformed rows from causing system errors.

Issue 4
Passwords are stored as plain text in Login.csv.

Resolution
Password encryption was not implemented due to the scope of the project.

Team Contributions Table

Member 1
Role
System Developer

Contributions
System architecture design
Payroll module implementation
User interface development

Member 2
Role
Developer

Contributions
Employee management module
Attendance system implementation

Member 3
Role
Developer

Contributions
Leave request system
Password reset system
System testing and documentation