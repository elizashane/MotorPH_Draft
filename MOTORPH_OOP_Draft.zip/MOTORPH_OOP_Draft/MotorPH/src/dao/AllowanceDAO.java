package dao;

import java.util.List;

public class AllowanceDAO {

    // Path to the CSV file that stores the allowance information
    private static final String FILE_PATH = "data/Allowance.csv";

    // CSVHandler object used to read the CSV file
    private final CSVHandler csvHandler = new CSVHandler();

    // Retrieves the Rice Subsidy allowance for a specific employee
    public double getRiceSubsidy(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Start at index 1 to skip the header row
        for (int i = 1; i < rows.size(); i++) {

            // Each row is stored as an array of Strings
            String[] row = rows.get(i);

            // Skip the row if it does not contain enough columns
            if (row.length < 4) {
                continue;
            }

            // Check if the employee number in column 0 matches the requested employee
            if (row[0].trim().equalsIgnoreCase(employeeNumber.trim())) {

                // Return the rice subsidy value found in column 1
                return parseDouble(row[1]);
            }
        }

        // If the employee is not found, return 0
        return 0.0;
    }

    // Retrieves the Phone Allowance for a specific employee
    public double getPhoneAllowance(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Ensure row contains the expected number of columns
            if (row.length < 4) {
                continue;
            }

            // Check if the employee number matches
            if (row[0].trim().equalsIgnoreCase(employeeNumber.trim())) {

                // Return phone allowance value located in column 2
                return parseDouble(row[2]);
            }
        }

        // Return 0 if employee is not found
        return 0.0;
    }

    // Retrieves the Clothing Allowance for a specific employee
    public double getClothingAllowance(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip invalid rows
            if (row.length < 4) {
                continue;
            }

            // Compare employee numbers
            if (row[0].trim().equalsIgnoreCase(employeeNumber.trim())) {

                // Return clothing allowance value located in column 3
                return parseDouble(row[3]);
            }
        }

        // Return 0 if employee does not exist in the file
        return 0.0;
    }

    // Calculates the total allowance for an employee
    public double getTotalAllowance(String employeeNumber) {

        // Add together all allowance types
        return getRiceSubsidy(employeeNumber)
                + getPhoneAllowance(employeeNumber)
                + getClothingAllowance(employeeNumber);
    }

    // Helper method used to safely convert a String to a double
    private double parseDouble(String value) {

        try {
            // Remove whitespace and convert to double
            return Double.parseDouble(value.trim());
        } catch (Exception e) {

            // If conversion fails (invalid number), return 0
            return 0.0;
        }
    }
}