package dao;

import java.util.ArrayList;
import java.util.List;

import model.AttendanceRecord;

public class AttendanceDAO {

    // Path to the CSV file that stores attendance records
    private static final String FILE_PATH = "data/TimeTracker.csv";

    // CSVHandler object used to read and write CSV data
    private final CSVHandler csvHandler = new CSVHandler();

    // Records a new Time-In entry for an employee
    public void timeIn(AttendanceRecord record) {

        // Convert the AttendanceRecord object into a row format for the CSV file
        String[] row = {
            record.getAttendanceId(),   // Unique attendance ID
            record.getEmployeeNumber(), // Employee number
            record.getDate(),           // Date of attendance
            record.getTimeIn(),         // Time-in value
            record.getTimeOut()         // Time-out value (usually empty initially)
        };

        // Append the new attendance row to the CSV file
        csvHandler.appendRow(FILE_PATH, row);
    }

    // Updates the Time-Out value of an employee for a specific date
    public void timeOut(String employeeNumber, String date, String timeOut) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Loop through rows while skipping the header
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Check if the employee number and date match,
            // and ensure that the time-out field is still empty
            if (row[1].equalsIgnoreCase(employeeNumber.trim())
                    && row[2].equals(date)
                    && row[4].trim().isEmpty()) {

                // Update the time-out column (column index 4)
                row[4] = timeOut;

                // Replace the updated row in the list
                rows.set(i, row);

                // Stop searching after the correct record is found
                break;
            }
        }

        // Rewrite the updated data back into the CSV file
        csvHandler.writeCSV(FILE_PATH, rows);
    }

    // Retrieves all attendance records for a specific employee
    public List<AttendanceRecord> getAttendanceByEmployee(String employeeNumber) {

        // List that will store all attendance records found
        List<AttendanceRecord> records = new ArrayList<>();

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Loop through rows while skipping the header
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows that do not contain enough columns
            if (row.length < 5) {
                continue;
            }

            // Check if the row belongs to the requested employee
            if (row[1].equalsIgnoreCase(employeeNumber.trim())) {

                // Convert the CSV row into an AttendanceRecord object
                records.add(new AttendanceRecord(
                    row[0], // Attendance ID
                    row[1], // Employee Number
                    row[2], // Date
                    row[3], // Time In
                    row[4]  // Time Out
                ));
            }
        }

        // Return the list of attendance records for that employee
        return records;
    }
}