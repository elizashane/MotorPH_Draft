package dao;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CSVHandler {

    // Reads a CSV file and returns the contents as a list of String arrays
    public List<String[]> readCSV(String filePath) {

        // List that will store each row from the CSV file
        List<String[]> rows = new ArrayList<>();

        // Create a File object using the provided file path
        File file = new File(filePath);

        // If the file does not exist, return an empty list
        if (!file.exists()) {
            return rows;
        }

        // Try-with-resources automatically closes the BufferedReader
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            String line;

            // Read the file line by line
            while ((line = br.readLine()) != null) {

                // Split each line using commas and store it as an array
                // "-1" ensures empty values are preserved
                rows.add(line.split(",", -1));
            }

        } catch (IOException e) {

            // Print the error if file reading fails
            e.printStackTrace();
        }

        // Return the list of rows
        return rows;
    }

    // Writes an entire list of rows back into a CSV file
    public void writeCSV(String filePath, List<String[]> rows) {

        // Try-with-resources ensures the writer closes automatically
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath))) {

            // Loop through every row in the list
            for (String[] row : rows) {

                // Join the row values into a single comma-separated string
                pw.println(String.join(",", row));
            }

        } catch (IOException e) {

            // Print error if writing fails
            e.printStackTrace();
        }
    }

    // Appends a new row to the end of the CSV file
    public void appendRow(String filePath, String[] row) {

        // "true" enables append mode so existing data is not overwritten
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath, true))) {

            // Convert the row array into a comma-separated line
            pw.println(String.join(",", row));

        } catch (IOException e) {

            // Print error if writing fails
            e.printStackTrace();
        }
    }
}