package dao;

import java.util.ArrayList;
import java.util.List;

import model.Employee;

public class EmployeeDAO {

    // Path to the CSV file containing employee records
    private static final String FILE_PATH = "data/Employee.csv";

    // CSVHandler object used to read and write CSV data
    private final CSVHandler csvHandler = new CSVHandler();

    // Retrieves all employees from the CSV file
    public List<Employee> getAllEmployees() {

        // List that will store Employee objects
        List<Employee> employees = new ArrayList<>();

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Start at index 1 to skip the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows that do not contain the required number of columns
            if (row.length < 13) {
                continue;
            }

            // Create a new Employee object
            Employee employee = new Employee();

            // Assign CSV values to the Employee object's attributes
            employee.setEmployeeNumber(row[0].trim());
            employee.setLastName(row[1].trim());
            employee.setFirstName(row[2].trim());
            employee.setBirthday(row[3].trim());
            employee.setAddress(row[4].trim());
            employee.setPhoneNumber(row[5].trim());
            employee.setSss(row[6].trim());
            employee.setPhilhealth(row[7].trim());
            employee.setTin(row[8].trim());
            employee.setPagibig(row[9].trim());
            employee.setStatus(row[10].trim());
            employee.setPosition(row[11].trim());

            // Format department name before assigning
            employee.setDepartment(formatName(row[12].trim()));

            // Add the employee object to the list
            employees.add(employee);
        }

        // Return the complete employee list
        return employees;
    }

    // Finds an employee using the employee number
    public Employee findEmployee(String employeeNumber) {

        // Loop through all employees
        for (Employee employee : getAllEmployees()) {

            // Check if the employee number matches
            if (employee.getEmployeeNumber().equalsIgnoreCase(employeeNumber.trim())) {
                return employee;
            }
        }

        // Return null if employee is not found
        return null;
    }

    // Alternative method that simply calls findEmployee
    public Employee findByEmployeeNumber(String employeeNumber) {
        return findEmployee(employeeNumber);
    }

    // Adds a new employee record to the CSV file
    public void addEmployee(Employee employee) {

        // Convert Employee object fields into a CSV row
        String[] row = {
            employee.getEmployeeNumber(),
            employee.getLastName(),
            employee.getFirstName(),

            // Prevent null values by replacing them with empty strings
            employee.getBirthday() == null ? "" : employee.getBirthday(),
            employee.getAddress() == null ? "" : employee.getAddress(),
            employee.getPhoneNumber() == null ? "" : employee.getPhoneNumber(),
            employee.getSss() == null ? "" : employee.getSss(),
            employee.getPhilhealth() == null ? "" : employee.getPhilhealth(),
            employee.getTin() == null ? "" : employee.getTin(),
            employee.getPagibig() == null ? "" : employee.getPagibig(),
            employee.getStatus() == null ? "" : employee.getStatus(),
            employee.getPosition() == null ? "" : employee.getPosition(),
            employee.getDepartment() == null ? "" : employee.getDepartment()
        };

        // Append the new employee record to the CSV file
        csvHandler.appendRow(FILE_PATH, row);
    }

    // Updates an existing employee record
    public void updateEmployee(Employee updatedEmployee) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Loop through rows while skipping the header
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Find the row that matches the employee number
            if (row[0].equalsIgnoreCase(updatedEmployee.getEmployeeNumber().trim())) {

                // Replace the row with updated employee data
                rows.set(i, new String[] {
                    updatedEmployee.getEmployeeNumber(),
                    updatedEmployee.getLastName(),
                    updatedEmployee.getFirstName(),
                    updatedEmployee.getBirthday() == null ? "" : updatedEmployee.getBirthday(),
                    updatedEmployee.getAddress() == null ? "" : updatedEmployee.getAddress(),
                    updatedEmployee.getPhoneNumber() == null ? "" : updatedEmployee.getPhoneNumber(),
                    updatedEmployee.getSss() == null ? "" : updatedEmployee.getSss(),
                    updatedEmployee.getPhilhealth() == null ? "" : updatedEmployee.getPhilhealth(),
                    updatedEmployee.getTin() == null ? "" : updatedEmployee.getTin(),
                    updatedEmployee.getPagibig() == null ? "" : updatedEmployee.getPagibig(),
                    updatedEmployee.getStatus() == null ? "" : updatedEmployee.getStatus(),
                    updatedEmployee.getPosition() == null ? "" : updatedEmployee.getPosition(),
                    updatedEmployee.getDepartment() == null ? "" : updatedEmployee.getDepartment()
                });

                // Stop searching after the record is updated
                break;
            }
        }

        // Save the updated data back to the CSV file
        csvHandler.writeCSV(FILE_PATH, rows);
    }

    // Deletes an employee record based on employee number
    public void deleteEmployee(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Create a new list to store updated rows
        List<String[]> updatedRows = new ArrayList<>();

        // Preserve the header row
        if (!rows.isEmpty()) {
            updatedRows.add(rows.get(0));
        }

        // Copy all rows except the one to be deleted
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            if (!row[0].equalsIgnoreCase(employeeNumber.trim())) {
                updatedRows.add(row);
            }
        }

        // Rewrite the CSV file with the updated list
        csvHandler.writeCSV(FILE_PATH, updatedRows);
    }

    // Formats names by swapping two-word names
    // Example: "HR Department" -> "Department HR"
    private String formatName(String name) {

        if (name == null || name.trim().isEmpty()) {
            return "";
        }

        String[] parts = name.trim().split("\\s+");

        // If the name has exactly two words, swap them
        if (parts.length == 2) {
            return parts[1] + " " + parts[0];
        }

        // Otherwise return the name unchanged
        return name;
    }
}