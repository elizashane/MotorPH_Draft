package dao;

import java.util.ArrayList;
import java.util.List;

import enums.LeaveStatus;
import model.LeaveRequest;

public class LeaveRequestDAO {

    // Path to the CSV file that stores leave request records
    private static final String FILE_PATH = "data/LeaveRequests.csv";

    // CSVHandler used to read and write CSV data
    private final CSVHandler csvHandler = new CSVHandler();

    // Adds a new leave request to the CSV file
    public void addLeaveRequest(LeaveRequest request) {

        // Convert the LeaveRequest object into a CSV row
        String[] row = {
            request.getLeaveId(),            // Unique leave request ID
            request.getEmployeeNumber(),     // Employee number requesting leave
            request.getStartDate(),          // Leave start date
            request.getEndDate(),            // Leave end date
            request.getReason(),             // Reason for leave
            request.getStatus().name(),      // Leave status (Pending, Approved, Rejected)

            // If the request has not been reviewed yet, store an empty string
            request.getReviewedBy() == null ? "" : request.getReviewedBy()
        };

        // Append the leave request row to the CSV file
        csvHandler.appendRow(FILE_PATH, row);
    }

    // Updates the status of an existing leave request
    public void updateLeaveStatus(String leaveId, LeaveStatus status, String reviewedBy) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Loop through rows while skipping the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Find the leave request with the matching leave ID
            if (row[0].equalsIgnoreCase(leaveId.trim())) {

                // Update the status column
                row[5] = status.name();

                // Record the name or ID of the reviewer
                row[6] = reviewedBy;

                // Replace the updated row in the list
                rows.set(i, row);

                // Stop searching after updating the record
                break;
            }
        }

        // Save the updated data back to the CSV file
        csvHandler.writeCSV(FILE_PATH, rows);
    }

    // Retrieves all leave requests stored in the CSV file
    public List<LeaveRequest> getAllLeaveRequests() {

        // List that will store LeaveRequest objects
        List<LeaveRequest> requests = new ArrayList<>();

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows that do not contain enough columns
            if (row.length < 7) {
                continue;
            }

            // Convert each CSV row into a LeaveRequest object
            requests.add(new LeaveRequest(
                row[0],                         // Leave ID
                row[1],                         // Employee Number
                row[2],                         // Start Date
                row[3],                         // End Date
                row[4],                         // Reason
                LeaveStatus.valueOf(row[5]),    // Leave Status (Enum)
                row[6]                          // Reviewed By
            ));
        }

        // Return the list of leave requests
        return requests;
    }

    // Retrieves leave requests submitted by a specific employee
    public List<LeaveRequest> getLeaveRequestsByEmployee(String employeeNumber) {

        // List that will store matching leave requests
        List<LeaveRequest> requests = new ArrayList<>();

        // Loop through all leave requests
        for (LeaveRequest request : getAllLeaveRequests()) {

            // Check if the request belongs to the specified employee
            if (request.getEmployeeNumber().equalsIgnoreCase(employeeNumber.trim())) {
                requests.add(request);
            }
        }

        // Return the filtered list
        return requests;
    }
}