package dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import model.PasswordResetRequest;

public class PasswordResetDAO {

    // Path to the CSV file that stores password reset requests
    private static final String FILE_PATH = "data/Password_Reset_Requests.csv";

    // CSVHandler object used to read and write CSV data
    private final CSVHandler csvHandler = new CSVHandler();

    // Retrieves all password reset requests from the CSV file
    public List<PasswordResetRequest> getAllRequests() {

        // List that will store PasswordResetRequest objects
        List<PasswordResetRequest> requests = new ArrayList<>();

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Loop through rows while skipping the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows that do not contain the required number of columns
            if (row.length < 4) {
                continue;
            }

            // Convert the CSV row into a PasswordResetRequest object
            requests.add(new PasswordResetRequest(
                row[0].trim(), // Employee number requesting reset
                row[1].trim(), // Username associated with the account
                row[2].trim(), // Date the request was submitted
                row[3].trim()  // Current request status (e.g., PENDING)
            ));
        }

        // Return the list of password reset requests
        return requests;
    }

    // Adds a new password reset request to the CSV file
    public void addRequest(String employeeNumber, String username) {

        // Convert request data into a CSV row
        String[] row = {
            employeeNumber.trim(),         // Employee number
            username.trim(),               // Username
            LocalDate.now().toString(),    // Automatically record the current date
            "PENDING"                      // Default status when request is created
        };

        // Append the new request to the CSV file
        csvHandler.appendRow(FILE_PATH, row);
    }
}