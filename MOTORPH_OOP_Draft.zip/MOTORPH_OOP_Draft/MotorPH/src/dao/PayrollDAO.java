package dao;

import java.util.ArrayList;
import java.util.List;

import model.PayrollRecord;

public class PayrollDAO {

    // Path to the CSV file that stores payroll records
    private static final String FILE_PATH = "data/SalaryLogs.csv";

    // CSVHandler used to read and write payroll data from the CSV file
    private final CSVHandler csvHandler = new CSVHandler();

    // Saves a payroll record to the CSV file
    public void savePayroll(PayrollRecord payroll) {

        // Convert the PayrollRecord object into a CSV row
        String[] row = {
            payroll.getPayrollId(),              // Unique payroll record ID
            payroll.getEmployeeNumber(),         // Employee number
            payroll.getPeriodStart(),            // Payroll period start date
            payroll.getPeriodEnd(),              // Payroll period end date
            String.valueOf(payroll.getBasicSalary()),
            String.valueOf(payroll.getAllowance()),
            String.valueOf(payroll.getGrossSalary()),
            String.valueOf(payroll.getTax()),
            String.valueOf(payroll.getSss()),
            String.valueOf(payroll.getPhilhealth()),
            String.valueOf(payroll.getPagibig()),
            String.valueOf(payroll.getTotalDeductions()),
            String.valueOf(payroll.getNetSalary())
        };

        // Append the payroll row to the CSV file
        csvHandler.appendRow(FILE_PATH, row);
    }

    // Retrieves all payroll records for a specific employee
    public List<PayrollRecord> getPayrollByEmployee(String employeeNumber) {

        // List that will store payroll records
        List<PayrollRecord> payrollRecords = new ArrayList<>();

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows that do not contain enough columns
            if (row.length < 13) {
                continue;
            }

            // Check if the row belongs to the requested employee
            if (row[1].equalsIgnoreCase(employeeNumber.trim())) {

                // Convert the CSV row into a PayrollRecord object
                payrollRecords.add(new PayrollRecord(
                    row[0],                     // Payroll ID
                    row[1],                     // Employee Number
                    row[2],                     // Period Start
                    row[3],                     // Period End
                    parseDouble(row[4]),        // Basic Salary
                    parseDouble(row[5]),        // Allowance
                    parseDouble(row[6]),        // Gross Salary
                    parseDouble(row[7]),        // Tax
                    parseDouble(row[8]),        // SSS Deduction
                    parseDouble(row[9]),        // PhilHealth Deduction
                    parseDouble(row[10]),       // Pag-IBIG Deduction
                    parseDouble(row[11]),       // Total Deductions
                    parseDouble(row[12])        // Net Salary
                ));
            }
        }

        // Return the list of payroll records for that employee
        return payrollRecords;
    }

    // Helper method used to safely convert String values into double
    private double parseDouble(String value) {

        try {
            return Double.parseDouble(value.trim());
        } catch (Exception e) {

            // Return 0 if the value cannot be converted
            return 0.0;
        }
    }

    // Retrieves the most recent payroll record for an employee
    public PayrollRecord getLatestPayroll(String employeeNumber) {

        // Get all payroll records for the employee
        List<PayrollRecord> records = getPayrollByEmployee(employeeNumber);

        // If no records exist, return null
        if (records.isEmpty()) {
            return null;
        }

        // Return the last payroll record in the list (latest entry)
        return records.get(records.size() - 1);
    }
}