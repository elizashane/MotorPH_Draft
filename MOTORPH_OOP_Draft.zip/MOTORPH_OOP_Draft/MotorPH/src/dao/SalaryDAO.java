package dao;

import java.util.List;

public class SalaryDAO {

    // Path to the CSV file that stores salary information
    private static final String FILE_PATH = "data/Salary.csv";

    // CSVHandler used to read salary data from the CSV file
    private final CSVHandler csvHandler = new CSVHandler();

    // Retrieves the basic salary of an employee
    public double getBasicSalary(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows with missing columns
            if (row.length < 4) {
                continue;
            }

            // Check if the employee number matches
            if (row[0].trim().equalsIgnoreCase(employeeNumber.trim())) {

                // Return the basic salary stored in column 1
                return parseDouble(row[1]);
            }
        }

        // Return 0 if the employee is not found
        return 0.0;
    }

    // Retrieves the hourly rate of an employee
    public double getHourlyRate(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip incomplete rows
            if (row.length < 4) {
                continue;
            }

            // Check if the employee number matches
            if (row[0].trim().equalsIgnoreCase(employeeNumber.trim())) {

                // Return the hourly rate stored in column 2
                return parseDouble(row[2]);
            }
        }

        // Return 0 if the employee is not found
        return 0.0;
    }

    // Retrieves the gross semi-monthly salary rate of an employee
    public double getGrossSemiMonthlyRate(String employeeNumber) {

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows with missing columns
            if (row.length < 4) {
                continue;
            }

            // Check if the employee number matches
            if (row[0].trim().equalsIgnoreCase(employeeNumber.trim())) {

                // Return the semi-monthly rate stored in column 3
                return parseDouble(row[3]);
            }
        }

        // Return 0 if the employee is not found
        return 0.0;
    }

    // Helper method used to safely convert a String to a double
    private double parseDouble(String value) {

        try {
            // Remove extra spaces and convert to double
            return Double.parseDouble(value.trim());
        } catch (Exception e) {

            // Return 0 if conversion fails
            return 0.0;
        }
    }
}