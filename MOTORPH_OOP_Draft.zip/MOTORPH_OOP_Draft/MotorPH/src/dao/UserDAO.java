package dao;

import java.util.ArrayList;
import java.util.List;

import model.Admin;
import model.Finance;
import model.HR;
import model.ITStaff;
import model.RegularEmployee;
import model.User;

public class UserDAO {

    // Path to the CSV file that stores login credentials and user roles
    private static final String FILE_PATH = "data/Login.csv";

    // CSVHandler used to read login data from the CSV file
    private final CSVHandler csvHandler = new CSVHandler();

    // Retrieves all users from the Login.csv file
    public List<User> getAllUsers() {

        // List that will store User objects
        List<User> users = new ArrayList<>();

        // Read all rows from the CSV file
        List<String[]> rows = csvHandler.readCSV(FILE_PATH);

        // Skip the header row
        for (int i = 1; i < rows.size(); i++) {

            String[] row = rows.get(i);

            // Skip rows that do not contain the required columns
            if (row.length < 5) {
                continue;
            }

            // Extract values from the CSV row
            String employeeNumber = row[0].trim();
            String username = row[1].trim();
            String role = row[2].trim().toUpperCase();
            String password = row[3].trim();

            // Create a User object based on the role and add it to the list
            users.add(createUserByRole(username, password, role, employeeNumber));
        }

        // Return the complete list of users
        return users;
    }

    // Finds a user based on username
    public User findByUsername(String username) {

        // Loop through all users
        for (User user : getAllUsers()) {

            // Compare usernames ignoring case differences
            if (user.getUsername().trim().equalsIgnoreCase(username.trim())) {
                return user;
            }
        }

        // Return null if the user is not found
        return null;
    }

    // Validates login credentials (username and password)
    public User validateCredentials(String username, String password) {

        // Loop through all users
        for (User user : getAllUsers()) {

            // Check if both username and password match
            if (user.getUsername().trim().equalsIgnoreCase(username.trim())
                    && user.getPassword().trim().equals(password.trim())) {
                return user;
            }
        }

        // Return null if credentials are invalid
        return null;
    }

    // Factory method that creates a specific User object based on role
    private User createUserByRole(String username, String password, String role, String employeeNumber) {

        switch (role) {

            case "ADMIN":
                return new Admin(username, password, employeeNumber);

            case "HR":
                return new HR(username, password, employeeNumber);

            case "FINANCE":
                return new Finance(username, password, employeeNumber);

            case "IT":
                return new ITStaff(username, password, employeeNumber);

            case "EMPLOYEE":
            default:
                return new RegularEmployee(username, password, employeeNumber);
        }
    }
}