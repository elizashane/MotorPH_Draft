package enums;

// Enumeration used to represent the possible states of a leave request
public enum LeaveStatus {

    // The leave request has been submitted but not yet reviewed
    PENDING,

    // The leave request has been reviewed and approved
    APPROVED,

    // The leave request has been reviewed and rejected
    REJECTED
}