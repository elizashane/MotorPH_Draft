package enums;

// Enumeration that defines the different user roles in the system
public enum Role {

    // Administrator role with full system control
    ADMIN,

    // Human Resources role responsible for employee management and leave processing
    HR,

    // Finance role responsible for payroll and financial records
    FINANCE,

    // IT role responsible for technical support and system maintenance
    IT,

    // Default role assigned to regular employees
    EMPLOYEE
}