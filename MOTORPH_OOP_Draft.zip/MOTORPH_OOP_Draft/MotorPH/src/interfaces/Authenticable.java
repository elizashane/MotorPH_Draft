package interfaces;

// Interface that defines authentication behavior for classes that support login
public interface Authenticable {

    // Method used to verify login credentials
    // Classes implementing this interface must provide their own login logic
    boolean login(String username, String password);
}