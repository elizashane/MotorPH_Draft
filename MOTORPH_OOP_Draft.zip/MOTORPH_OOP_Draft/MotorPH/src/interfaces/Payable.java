package interfaces;

// Interface that defines payroll calculation behavior
public interface Payable {

    // Calculates the gross salary of an employee
    // Gross salary typically includes basic salary plus allowances
    double calculateGrossSalary();

    // Calculates the net salary of an employee
    // Net salary is the remaining salary after deductions such as taxes and contributions
    double calculateNetSalary();
}