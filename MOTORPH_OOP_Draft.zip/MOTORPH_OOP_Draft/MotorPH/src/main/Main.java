package main;

import javax.swing.SwingUtilities;
import ui.LoginFrame;

// Main entry point of the application
public class Main {

    public static void main(String[] args) {

        // Ensures that the GUI is created and updated on the Event Dispatch Thread (EDT)
        // This is the recommended practice for Swing applications to avoid threading issues
        SwingUtilities.invokeLater(LoginFrame::new);
    }
}