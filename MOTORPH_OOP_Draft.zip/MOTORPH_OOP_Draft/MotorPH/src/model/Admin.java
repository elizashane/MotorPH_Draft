package model;

import enums.Role;

// Admin class represents a system administrator user
// It extends the User class and inherits its properties and behaviors
public class Admin extends User {

    // Default constructor
    // Calls the parent constructor and sets the role as ADMIN
    public Admin() {
        super();
        setRole(Role.ADMIN);
    }

    // Parameterized constructor used when creating an Admin user with login details
    public Admin(String username, String password, String employeeNumber) {

        // Calls the User constructor and automatically assigns the ADMIN role
        super(username, password, Role.ADMIN, employeeNumber);
    }

    // Returns the name of the dashboard associated with the Admin role
    @Override
    public String getDashboardName() {
        return "Admin Dashboard";
    }
}