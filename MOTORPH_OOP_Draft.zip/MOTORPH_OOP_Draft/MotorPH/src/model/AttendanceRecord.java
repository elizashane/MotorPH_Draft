package model;

// AttendanceRecord class represents an employee's attendance entry
// It stores information about time-in and time-out for a specific date
public class AttendanceRecord {

    // Unique identifier for the attendance record
    private String attendanceId;

    // Employee number associated with this attendance record
    private String employeeNumber;

    // Date of the attendance entry
    private String date;

    // Time the employee clocked in
    private String timeIn;

    // Time the employee clocked out
    private String timeOut;

    // Default constructor
    public AttendanceRecord(){
    }

    // Parameterized constructor used to create a full attendance record
    public AttendanceRecord(String attendanceId, String employeeNumber, String date, String timeIn, String timeOut) {
        this.attendanceId = attendanceId;
        this.employeeNumber = employeeNumber;
        this.date = date;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
    }

    // Getter for attendance ID
    public String getAttendanceId(){
        return attendanceId;
    }

    // Setter for attendance ID
    public void setAttendanceId(String attendanceId){
        this.attendanceId = attendanceId;
    }

    // Getter for employee number
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    // Setter for employee number
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    // Getter for attendance date
    public String getDate(){
        return date;
    }

    // Setter for attendance date
    public void setDate(String date){
        this.date = date;
    }

    // Getter for time-in value
    public String getTimeIn(){
        return timeIn;
    }

    // Setter for time-in value
    public void setTimeIn(String timeIn){
        this.timeIn = timeIn;
    }

    // Getter for time-out value
    public String getTimeOut(){
        return timeOut;
    }
    
    // Setter for time-out value
    public void setTimeOut(String timeOut){
        this.timeOut = timeOut;
    }
}