package model;

import interfaces.Payable;

// Employee class represents an employee in the payroll system
// It extends the Person class and implements the Payable interface
public class Employee extends Person implements Payable {

    // Employee identification and work information
    private String employeeNumber;
    private String position;
    private String department;

    // Salary information
    private double basicSalary;
    private double allowance;

    // Government contribution identifiers
    private String sss;
    private String tin;
    private String pagibig;
    private String philhealth;

    // Additional personal details
    private String birthday;
    private String address;
    private String phoneNumber;
    private String status;

    // Default constructor
    public Employee() {
    }

    // Parameterized constructor to initialize employee data
    public Employee(String firstName, String lastName, String email,
                    String employeeNumber, String position, String department,
                    double basicSalary, double allowance,
                    String sss, String tin, String pagibig, String philhealth) {

        super(firstName, lastName, email);

        this.employeeNumber = employeeNumber;
        this.position = position;
        this.department = department;
        this.basicSalary = basicSalary;
        this.allowance = allowance;
        this.sss = sss;
        this.tin = tin;
        this.pagibig = pagibig;
        this.philhealth = philhealth;
    }

    // ===============================
    // Employee Identification Getters and Setters
    // ===============================

    // Returns the employee's unique employee number
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    // Sets the employee's unique employee number
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    // Returns the employee's job position
    public String getPosition() {
        return position;
    }

    // Sets the employee's job position
    public void setPosition(String position) {
        this.position = position;
    }

    // Returns the employee's department
    public String getDepartment() {
        return department;
    }

    // Sets the employee's department and formats the name if needed
    public void setDepartment(String department) {

        if (department == null || department.isEmpty()) {
            this.department = "";
            return;
        }

        String[] nameParts = department.trim().split("\\s+");

        if (nameParts.length == 2) {
            this.department = nameParts[1] + " " + nameParts[0];
        } else {
            this.department = department;
        }
    }

    // ===============================
    // Salary Getters and Setters
    // ===============================

    // Returns the employee's basic salary
    public double getBasicSalary() {
        return basicSalary;
    }

    // Sets the employee's basic salary
    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    // Returns the employee's allowance
    public double getAllowance() {
        return allowance;
    }

    // Sets the employee's allowance
    public void setAllowance(double allowance) {
        this.allowance = allowance;
    }

    // ===============================
    // Government ID Getters and Setters
    // ===============================

    // Returns the employee's SSS number
    public String getSss() {
        return sss;
    }

    // Sets the employee's SSS number
    public void setSss(String sss) {
        this.sss = sss;
    }

    // Returns the employee's TIN number
    public String getTin() {
        return tin;
    }

    // Sets the employee's TIN number
    public void setTin(String tin) {
        this.tin = tin;
    }

    // Returns the employee's Pag-IBIG number
    public String getPagibig() {
        return pagibig;
    }

    // Sets the employee's Pag-IBIG number
    public void setPagibig(String pagibig) {
        this.pagibig = pagibig;
    }

    // Returns the employee's PhilHealth number
    public String getPhilhealth() {
        return philhealth;
    }

    // Sets the employee's PhilHealth number
    public void setPhilhealth(String philhealth) {
        this.philhealth = philhealth;
    }

    // ===============================
    // Personal Information Getters and Setters
    // ===============================

    // Returns the employee's birthday
    public String getBirthday() {
        return birthday;
    }

    // Sets the employee's birthday
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    // Returns the employee's address
    public String getAddress() {
        return address;
    }

    // Sets the employee's address
    public void setAddress(String address) {
        this.address = address;
    }

    // Returns the employee's phone number
    public String getPhoneNumber() {
        return phoneNumber;
    }

    // Sets the employee's phone number
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // Returns the employee's employment status
    public String getStatus() {
        return status;
    }

    // Sets the employee's employment status
    public void setStatus(String status) {
        this.status = status;
    }

    // ===============================
    // Payroll Calculation Methods
    // ===============================

    // Calculates the gross salary (basic salary + allowance)
    @Override
    public double calculateGrossSalary() {
        return basicSalary + allowance;
    }

    // Calculates the net salary after deductions
    @Override
    public double calculateNetSalary() {

        double grossSalary = calculateGrossSalary();

        double tax = grossSalary * 0.10;
        double sssDeduction = grossSalary * 0.02;
        double philhealthDeduction = grossSalary * 0.015;
        double pagibigDeduction = 100.00;

        return grossSalary - (tax + sssDeduction + philhealthDeduction + pagibigDeduction);
    }
}