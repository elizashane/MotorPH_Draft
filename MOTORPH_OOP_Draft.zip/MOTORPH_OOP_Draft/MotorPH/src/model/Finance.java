package model;

import enums.Role;

// Finance class represents a finance department user
// It extends the User class and inherits authentication and user properties
public class Finance extends User {

    // Default constructor
    // Calls the parent constructor and sets the role as FINANCE
    public Finance(){
        super();
        setRole(Role.FINANCE);
    }

    // Parameterized constructor used when creating a Finance user with login details
    public Finance(String username, String password, String employeeNumber){

        // Calls the User constructor and assigns the FINANCE role
        super(username, password, Role.FINANCE, employeeNumber);
    }

    // Returns the name of the dashboard associated with the Finance role
    @Override
    public String getDashboardName(){
        return "Finance Dashboard";
    }
}