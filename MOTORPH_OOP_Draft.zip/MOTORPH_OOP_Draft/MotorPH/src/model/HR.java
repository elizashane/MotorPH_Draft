package model;

import enums.Role;

// HR class represents a Human Resources user in the system
// It extends the User class and inherits its properties and authentication behavior
public class HR extends User {

    // Default constructor
    // Calls the parent constructor and sets the role as HR
    public HR(){
        super();
        setRole(Role.HR);
    }

    // Parameterized constructor used when creating an HR user with login credentials
    public HR(String username, String password, String employeeNumber){

        // Calls the User constructor and automatically assigns the HR role
        super(username, password, Role.HR, employeeNumber);
    }

    // Returns the name of the dashboard associated with the HR role
    @Override
    public String getDashboardName(){
        return "HR Dashboard";
    }
}