package model;

import enums.Role;

// ITStaff class represents a user from the IT department
// It extends the User class and inherits authentication and user properties
public class ITStaff extends User {

    // Default constructor
    // Calls the parent constructor and assigns the IT role
    public ITStaff() {
        super();
        setRole(Role.IT);
    }

    // Parameterized constructor used when creating an IT staff user with login details
    public ITStaff(String username, String password, String employeeNumber){

        // Calls the User constructor and automatically assigns the IT role
        super(username, password, Role.IT, employeeNumber);
    }

    // Returns the name of the dashboard associated with the IT role
    @Override
    public String getDashboardName() {
        return  "IT Dashboard";
    }
}