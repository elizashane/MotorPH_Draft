package model;

import enums.LeaveStatus;

// LeaveRequest class represents a leave application submitted by an employee
// It stores the leave details, status, and the person who reviewed the request
public class LeaveRequest {

    // Unique identifier for the leave request
    private String leaveId;

    // Employee number of the employee requesting leave
    private String employeeNumber;

    // Start date of the leave
    private String startDate;

    // End date of the leave
    private String endDate;

    // Reason provided by the employee for the leave request
    private String reason;

    // Current status of the leave request (PENDING, APPROVED, REJECTED)
    private LeaveStatus status;

    // Name or identifier of the person who reviewed the request
    private String reviewedBy;

    // Default constructor
    // Automatically sets the leave status to PENDING
    public LeaveRequest() {
        this.status = LeaveStatus.PENDING;
    }

    // Parameterized constructor used to initialize a leave request with full details
    public LeaveRequest(String leaveId, String employeeNumber, String startDate,
                        String endDate, String reason, LeaveStatus status, String reviewedBy) {

        this.leaveId = leaveId;
        this.employeeNumber = employeeNumber;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.status = status;
        this.reviewedBy = reviewedBy;
    }

    // Returns the unique leave request ID
    public String getLeaveId() {
        return leaveId;
    }

    // Sets the leave request ID
    public void setLeaveId(String leaveId) {
        this.leaveId = leaveId;
    }

    // Returns the employee number of the requester
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    // Sets the employee number of the requester
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    // Returns the start date of the leave
    public String getStartDate() {
        return startDate;
    }

    // Sets the start date of the leave
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    // Returns the end date of the leave
    public String getEndDate() {
        return endDate;
    }

    // Sets the end date of the leave
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    // Returns the reason for the leave request
    public String getReason() {
        return reason;
    }

    // Sets the reason for the leave request
    public void setReason(String reason) {
        this.reason = reason;
    }

    // Returns the current status of the leave request
    public LeaveStatus getStatus() {
        return status;
    }

    // Sets the status of the leave request (Approved, Rejected, Pending)
    public void setStatus(LeaveStatus status) {
        this.status = status;
    }

    // Returns the name or ID of the reviewer
    public String getReviewedBy() {
        return reviewedBy;
    }

    // Sets the name or ID of the reviewer
    public void setReviewedBy(String reviewedBy) {
        this.reviewedBy = reviewedBy;
    }
}