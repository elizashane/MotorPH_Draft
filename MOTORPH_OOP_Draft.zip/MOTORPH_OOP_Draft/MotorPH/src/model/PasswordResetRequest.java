package model;

// PasswordResetRequest class represents a request made by a user
// to reset their account password
public class PasswordResetRequest {

    // Employee number of the user requesting the password reset
    private String employeeNumber;

    // Username associated with the account
    private String username;

    // Date when the reset request was submitted
    private String requestDate;

    // Current status of the request (e.g., PENDING, APPROVED, REJECTED)
    private String status;

    // Default constructor
    public PasswordResetRequest() {
    }

    // Parameterized constructor used to initialize a password reset request
    public PasswordResetRequest(String employeeNumber, String username, String requestDate, String status) {
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.requestDate = requestDate;
        this.status = status;
    }

    // Returns the employee number associated with the request
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    // Sets the employee number associated with the request
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    // Returns the username of the account requesting the password reset
    public String getUsername() {
        return username;
    }

    // Sets the username of the account requesting the password reset
    public void setUsername(String username) {
        this.username = username;
    }

    // Returns the date the reset request was submitted
    public String getRequestDate() {
        return requestDate;
    }

    // Sets the date the reset request was submitted
    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    // Returns the current status of the password reset request
    public String getStatus() {
        return status;
    }

    // Sets the status of the password reset request
    public void setStatus(String status) {
        this.status = status;
    }
}