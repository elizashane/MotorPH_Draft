package model;

// PayrollRecord class represents a payroll transaction for an employee
// It stores salary information, deductions, and the final net salary for a payroll period
public class PayrollRecord {

    // Unique identifier for the payroll record
    private String payrollId;

    // Employee number associated with the payroll record
    private String employeeNumber;

    // Payroll period start date
    private String periodStart;

    // Payroll period end date
    private String periodEnd;

    // Basic salary of the employee for the payroll period
    private double basicSalary;

    // Allowances given to the employee
    private double allowance;

    // Total gross salary before deductions
    private double grossSalary;

    // Tax deduction amount
    private double tax;

    // SSS deduction amount
    private double sss;

    // PhilHealth deduction amount
    private double philhealth;

    // Pag-IBIG deduction amount
    private double pagibig;

    // Total deductions (sum of all deductions)
    private double totalDeductions;

    // Final net salary after all deductions
    private double netSalary;

    // Default constructor
    public PayrollRecord() {
    }

    // Parameterized constructor used to initialize payroll information
    public PayrollRecord(String payrollId, String employeeNumber, String periodStart, String periodEnd,
                         double basicSalary, double allowance, double grossSalary,
                         double tax, double sss, double philhealth, double pagibig,
                         double totalDeductions, double netSalary) {

        this.payrollId = payrollId;
        this.employeeNumber = employeeNumber;
        this.periodStart = periodStart;
        this.periodEnd = periodEnd;
        this.basicSalary = basicSalary;
        this.allowance = allowance;
        this.grossSalary = grossSalary;
        this.tax = tax;
        this.sss = sss;
        this.philhealth = philhealth;
        this.pagibig = pagibig;
        this.totalDeductions = totalDeductions;
        this.netSalary = netSalary;
    }

    // Returns the payroll record ID
    public String getPayrollId() {
        return payrollId;
    }

    // Sets the payroll record ID
    public void setPayrollId(String payrollId) {
        this.payrollId = payrollId;
    }

    // Returns the employee number associated with the payroll record
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    // Sets the employee number associated with the payroll record
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    // Returns the payroll period start date
    public String getPeriodStart() {
        return periodStart;
    }

    // Sets the payroll period start date
    public void setPeriodStart(String periodStart) {
        this.periodStart = periodStart;
    }

    // Returns the payroll period end date
    public String getPeriodEnd() {
        return periodEnd;
    }

    // Sets the payroll period end date
    public void setPeriodEnd(String periodEnd) {
        this.periodEnd = periodEnd;
    }

    // Returns the basic salary amount
    public double getBasicSalary() {
        return basicSalary;
    }

    // Sets the basic salary amount
    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    // Returns the allowance amount
    public double getAllowance() {
        return allowance;
    }

    // Sets the allowance amount
    public void setAllowance(double allowance) {
        this.allowance = allowance;
    }

    // Returns the gross salary before deductions
    public double getGrossSalary() {
        return grossSalary;
    }

    // Sets the gross salary before deductions
    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    // Returns the tax deduction amount
    public double getTax() {
        return tax;
    }

    // Sets the tax deduction amount
    public void setTax(double tax) {
        this.tax = tax;
    }

    // Returns the SSS deduction amount
    public double getSss() {
        return sss;
    }

    // Sets the SSS deduction amount
    public void setSss(double sss) {
        this.sss = sss;
    }

    // Returns the PhilHealth deduction amount
    public double getPhilhealth() {
        return philhealth;
    }

    // Sets the PhilHealth deduction amount
    public void setPhilhealth(double philhealth) {
        this.philhealth = philhealth;
    }

    // Returns the Pag-IBIG deduction amount
    public double getPagibig() {
        return pagibig;
    }

    // Sets the Pag-IBIG deduction amount
    public void setPagibig(double pagibig) {
        this.pagibig = pagibig;
    }

    // Returns the total deductions applied to the payroll
    public double getTotalDeductions() {
        return totalDeductions;
    }

    // Sets the total deductions applied to the payroll
    public void setTotalDeductions(double totalDeductions) {
        this.totalDeductions = totalDeductions;
    }

    // Returns the final net salary after deductions
    public double getNetSalary() {
        return netSalary;
    }

    // Sets the final net salary after deductions
    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }
}