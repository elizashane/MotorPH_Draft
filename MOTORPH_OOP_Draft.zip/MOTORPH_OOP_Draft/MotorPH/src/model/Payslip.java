package model;

// Payslip class represents the final payroll document for an employee
// It combines employee information and the corresponding payroll record
public class Payslip {

    // Reference to the employee associated with the payslip
    private Employee employee;

    // Payroll record containing salary calculations and deductions
    private PayrollRecord payrollRecord;

    // Default constructor
    public Payslip() {
    }

    // Parameterized constructor used to create a payslip
    // with both employee information and payroll details
    public Payslip(Employee employee, PayrollRecord payrollRecord) {
        this.employee = employee;
        this.payrollRecord = payrollRecord;
    }

    // Returns the employee associated with the payslip
    public Employee getEmployee() {
        return employee;
    }

    // Sets the employee associated with the payslip
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    // Returns the payroll record linked to the payslip
    public PayrollRecord getPayrollRecord() {
        return payrollRecord;
    }

    // Sets the payroll record linked to the payslip
    public void setPayrollRecord(PayrollRecord payrollRecord) {
        this.payrollRecord = payrollRecord;
    }
}