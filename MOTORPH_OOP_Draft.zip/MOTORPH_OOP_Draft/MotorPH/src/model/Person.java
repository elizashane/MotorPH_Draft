package model;

// Person class represents a basic person entity
// It stores common personal information used by other classes like Employee
public class Person {

    // Person's first name
    private String firstName;

    // Person's last name
    private String lastName;

    // Person's email address
    private String email;

    // Default constructor
    public Person() {
    }

    // Parameterized constructor used to initialize person details
    public Person(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    // Returns the person's first name
    public String getFirstName() {
        return firstName;
    }

    // Sets the person's first name
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Returns the person's last name
    public String getLastName() {
        return lastName;
    }

    // Sets the person's last name
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Returns the person's email address
    public String getEmail() {
        return email;
    }

    // Sets the person's email address
    public void setEmail(String email) {
        this.email = email;
    }

    // Returns the full name of the person by combining first and last name
    public String getFullName() {
        return firstName + " " + lastName;
    }
}