package model;

import enums.Role;

// RegularEmployee class represents a standard employee user in the system
// It extends the User class and inherits authentication and user properties
public class RegularEmployee extends User {

    // Default constructor
    // Calls the parent constructor and assigns the EMPLOYEE role
    public RegularEmployee(){
        super();
        setRole(Role.EMPLOYEE);
    }

    // Parameterized constructor used when creating a regular employee user with login details
    public RegularEmployee(String username, String password, String employeeNumber) {

        // Calls the User constructor and automatically assigns the EMPLOYEE role
        super(username, password, Role.EMPLOYEE, employeeNumber);
    }

    // Returns the name of the dashboard associated with the regular employee role
    @Override
    public String getDashboardName(){
        return "Employee Dashboard";
    }
}