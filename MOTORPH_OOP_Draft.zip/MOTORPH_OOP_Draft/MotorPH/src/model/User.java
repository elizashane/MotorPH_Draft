package model;

import enums.Role;

// User is an abstract base class representing a system user
// It contains common authentication and identification fields
// Different user types (Admin, HR, Finance, ITStaff, RegularEmployee)
// will extend this class
public abstract class User {

    // Username used for login
    private String username;

    // Password used for authentication
    private String password;

    // Role assigned to the user (Admin, HR, Finance, IT, Employee)
    private Role role;

    // Employee number associated with the user account
    private String employeeNumber;

    // Default constructor
    public User(){
    }

    // Parameterized constructor used to initialize user credentials and role
    public User(String username, String password, Role role, String employeeNumber){
        this.username = username;
        this.password = password;
        this.role = role;
        this.employeeNumber = employeeNumber;
    }

    // Returns the username used for login
    public String getUsername() {
        return username;
    }

    // Sets the username used for login
    public void setUsername(String username) {
        this.username = username;
    }

    // Returns the password associated with the user account
    public String getPassword() {
        return password;
    }

    // Sets the password associated with the user account
    public void setPassword(String password) {
        this.password = password;
    }

    // Returns the role assigned to the user
    public Role getRole() {
        return role;
    }

    // Sets the role assigned to the user
    public void setRole(Role role) {
        this.role = role;
    }

    // Returns the employee number linked to the user account
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    // Sets the employee number linked to the user account
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    // Abstract method that must be implemented by subclasses
    // Each role will define its own dashboard name
    public abstract String getDashboardName();
}