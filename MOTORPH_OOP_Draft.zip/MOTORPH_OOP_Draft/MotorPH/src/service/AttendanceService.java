package service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

import dao.AttendanceDAO;
import model.AttendanceRecord;

// AttendanceService handles the business logic related to employee attendance
// It interacts with the AttendanceDAO to store and retrieve attendance data
public class AttendanceService {

    // DAO object used to access attendance records from the data layer
    private final AttendanceDAO attendanceDAO = new AttendanceDAO();

    // Records a time-in entry for an employee
    public void timeIn(String employeeNumber) {

        // Create a new attendance record with a unique ID
        AttendanceRecord record = new AttendanceRecord(

            // Generate a unique attendance ID using UUID
            "ATT-" + UUID.randomUUID().toString().substring(0, 8),

            // Employee number for the attendance entry
            employeeNumber,

            // Current date when the employee clocks in
            LocalDate.now().toString(),

            // Current time when the employee clocks in (nanoseconds removed)
            LocalTime.now().withNano(0).toString(),

            // Time-out is empty initially
            ""
        );

        // Save the time-in record using the DAO
        attendanceDAO.timeIn(record);
    }

    // Records a time-out entry for an employee
    public void timeOut(String employeeNumber) {

        // Update the employee's attendance record with the current time-out
        attendanceDAO.timeOut(
            employeeNumber,
            LocalDate.now().toString(),
            LocalTime.now().withNano(0).toString()
        );
    }

    // Retrieves all attendance records for a specific employee
    public List<AttendanceRecord> getAttendance(String employeeNumber) {

        // Calls the DAO to fetch attendance records for the employee
        return attendanceDAO.getAttendanceByEmployee(employeeNumber);
    }
}