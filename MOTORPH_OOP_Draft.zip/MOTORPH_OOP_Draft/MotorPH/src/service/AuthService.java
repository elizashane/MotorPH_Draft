package service;

import dao.UserDAO;
import model.User;

// AuthService handles authentication-related business logic
// It validates user login credentials using the UserDAO
public class AuthService {

    // DAO object used to access user login data
    private final UserDAO userDAO = new UserDAO();

    // Attempts to log in a user using a username and password
    public User login(String username, String password) {

        // Calls the UserDAO to validate the provided credentials
        // If the credentials match a record, the corresponding User object is returned
        // If not, null is returned
        return userDAO.validateCredentials(username, password);
    }
}