package service;

import java.util.List;

import dao.EmployeeDAO;
import model.Employee;

// EmployeeService handles the business logic related to employee management
// It acts as a bridge between the user interface and the EmployeeDAO
public class EmployeeService {

    // DAO object used to access employee data from the CSV file
    private final EmployeeDAO employeeDAO = new EmployeeDAO();

    // Adds a new employee to the system
    public String addEmployee(Employee employee) {

        // Validate that the employee number is provided
        if (employee.getEmployeeNumber() == null || employee.getEmployeeNumber().trim().isEmpty()) {
            return "Employee number is required.";
        }

        // Check if an employee with the same number already exists
        if (findEmployee(employee.getEmployeeNumber()) != null) {
            return "Employee number already exists.";
        }

        // Save the employee using the DAO
        employeeDAO.addEmployee(employee);

        // Return success message
        return "Employee added successfully.";
    }

    // Updates an existing employee's information
    public String updateEmployee(Employee employee) {

        // Validate that the employee number is provided
        if (employee.getEmployeeNumber() == null || employee.getEmployeeNumber().trim().isEmpty()) {
            return "Employee number is required.";
        }

        // Update the employee information in the data source
        employeeDAO.updateEmployee(employee);

        // Return success message
        return "Employee updated successfully.";
    }

    // Deletes an employee from the system
    public String deleteEmployee(String employeeNumber) {

        // Validate that the employee number is provided
        if (employeeNumber == null || employeeNumber.trim().isEmpty()) {
            return "Employee number is required.";
        }

        // Remove the employee record using the DAO
        employeeDAO.deleteEmployee(employeeNumber);

        // Return success message
        return "Employee deleted successfully.";
    }

    // Retrieves a list of all employees
    public List<Employee> getAllEmployees() {

        // Call the DAO to retrieve all employee records
        return employeeDAO.getAllEmployees();
    }

    // Finds a specific employee by employee number
    public Employee findEmployee(String employeeNumber) {

        // Call the DAO to search for the employee
        return employeeDAO.findByEmployeeNumber(employeeNumber);
    }
}