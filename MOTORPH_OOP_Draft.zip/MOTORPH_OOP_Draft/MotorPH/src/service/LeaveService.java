package service;

import java.util.List;
import java.util.UUID;

import dao.LeaveRequestDAO;
import enums.LeaveStatus;
import model.LeaveRequest;

// LeaveService handles the business logic related to employee leave requests
// It communicates with LeaveRequestDAO to store and retrieve leave data
public class LeaveService {

    // DAO object used to manage leave request records
    private final LeaveRequestDAO leaveRequestDAO = new LeaveRequestDAO();

    // Submits a new leave request for an employee
    public void submitLeave(String employeeNumber, String startDate, String endDate, String reason) {

        // Create a new leave request object
        LeaveRequest request = new LeaveRequest(

            // Generate a unique leave request ID
            "LV-" + UUID.randomUUID().toString().substring(0, 8),

            // Employee requesting the leave
            employeeNumber,

            // Start date of the leave
            startDate,

            // End date of the leave
            endDate,

            // Reason provided for the leave
            reason,

            // Default status is PENDING until reviewed
            LeaveStatus.PENDING,

            // No reviewer assigned yet
            ""
        );

        // Save the leave request using the DAO
        leaveRequestDAO.addLeaveRequest(request);
    }

    // Approves a leave request
    public void approveLeave(String leaveId, String reviewedBy) {

        // Update the leave request status to APPROVED
        leaveRequestDAO.updateLeaveStatus(leaveId, LeaveStatus.APPROVED, reviewedBy);
    }

    // Rejects a leave request
    public void rejectLeave(String leaveId, String reviewedBy) {

        // Update the leave request status to REJECTED
        leaveRequestDAO.updateLeaveStatus(leaveId, LeaveStatus.REJECTED, reviewedBy);
    }

    // Retrieves all leave requests in the system
    public List<LeaveRequest> getAllRequests() {

        // Call DAO to retrieve all leave records
        return leaveRequestDAO.getAllLeaveRequests();
    }

    // Retrieves the leave history of a specific employee
    public List<LeaveRequest> getEmployeeLeaveHistory(String employeeNumber) {

        // Call DAO to retrieve leave requests filtered by employee
        return leaveRequestDAO.getLeaveRequestsByEmployee(employeeNumber);
    }
}