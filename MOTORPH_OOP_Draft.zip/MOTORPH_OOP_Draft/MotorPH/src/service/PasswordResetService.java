package service;

import java.util.List;

import dao.PasswordResetDAO;
import model.PasswordResetRequest;

// PasswordResetService handles the business logic related to password reset requests
// It validates input and communicates with the PasswordResetDAO to store and retrieve requests
public class PasswordResetService {

    // DAO object used to access password reset request data
    private final PasswordResetDAO passwordResetDAO = new PasswordResetDAO();

    // Submits a new password reset request
    public String submitRequest(String employeeNumber, String username) {

        // Validate that the employee number is provided
        if (employeeNumber == null || employeeNumber.trim().isEmpty()) {
            return "Employee number is required.";
        }

        // Validate that the username is provided
        if (username == null || username.trim().isEmpty()) {
            return "Username is required.";
        }

        // Add the password reset request through the DAO
        passwordResetDAO.addRequest(employeeNumber, username);

        // Return confirmation message
        return "Password reset request submitted.";
    }

    // Retrieves all password reset requests
    public List<PasswordResetRequest> getAllRequests() {

        // Calls the DAO to fetch all stored password reset requests
        return passwordResetDAO.getAllRequests();
    }
}