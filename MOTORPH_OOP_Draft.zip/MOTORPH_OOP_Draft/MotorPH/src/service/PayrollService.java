package service;

import java.util.UUID;

import dao.AllowanceDAO;
import dao.PayrollDAO;
import dao.SalaryDAO;
import model.Employee;
import model.PayrollRecord;

// PayrollService handles payroll computation and processing logic
// It retrieves salary and allowance data, calculates deductions,
// and stores the payroll record using PayrollDAO
public class PayrollService {

    // DAO objects used to access payroll, salary, and allowance data
    private final PayrollDAO payrollDAO = new PayrollDAO();
    private final SalaryDAO salaryDAO = new SalaryDAO();
    private final AllowanceDAO allowanceDAO = new AllowanceDAO();

    // Processes payroll for a specific employee
    public PayrollRecord processPayroll(Employee employee) {

        // Create a new payroll record object
        PayrollRecord record = new PayrollRecord();

        // Retrieve employee number
        String employeeNumber = employee.getEmployeeNumber();

        // Get salary and allowance information from the data layer
        double basicSalary = salaryDAO.getBasicSalary(employeeNumber);
        double allowance = allowanceDAO.getTotalAllowance(employeeNumber);

        // Calculate gross salary
        double grossSalary = basicSalary + allowance;

        // Calculate deductions
        double tax = calculateTax(grossSalary);
        double sss = calculateSSS(grossSalary);
        double philhealth = calculatePhilHealth(grossSalary);
        double pagibig = calculatePagibig(grossSalary);

        // Calculate total deductions and final net salary
        double totalDeductions = tax + sss + philhealth + pagibig;
        double netSalary = grossSalary - totalDeductions;

        // Generate a unique payroll ID
        record.setPayrollId("PAY-" + UUID.randomUUID().toString().substring(0, 8));

        // Set payroll details
        record.setEmployeeNumber(employeeNumber);
        record.setPeriodStart("2026-03-01");
        record.setPeriodEnd("2026-03-15");
        record.setBasicSalary(basicSalary);
        record.setAllowance(allowance);
        record.setGrossSalary(grossSalary);
        record.setTax(tax);
        record.setSss(sss);
        record.setPhilhealth(philhealth);
        record.setPagibig(pagibig);
        record.setTotalDeductions(totalDeductions);
        record.setNetSalary(netSalary);

        // Save the payroll record using the DAO
        payrollDAO.savePayroll(record);

        // Return the processed payroll record
        return record;
    }

    // Retrieves the most recent payroll record for an employee
    public PayrollRecord getLatestPayroll(String employeeNumber) {
        return payrollDAO.getLatestPayroll(employeeNumber);
    }

    // Calculates tax deduction based on gross salary
    public double calculateTax(double grossSalary) {
        return grossSalary * 0.10;
    }

    // Calculates SSS contribution based on gross salary
    public double calculateSSS(double grossSalary) {
        return grossSalary * 0.02;
    }

    // Calculates PhilHealth contribution based on gross salary
    public double calculatePhilHealth(double grossSalary) {
        return grossSalary * 0.015;
    }

    // Calculates Pag-IBIG contribution (fixed amount)
    public double calculatePagibig(double grossSalary) {
        return 100.0;
    }
}