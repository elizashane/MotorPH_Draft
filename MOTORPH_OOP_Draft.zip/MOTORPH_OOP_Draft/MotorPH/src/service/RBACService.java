package service;

import enums.Role;

// RBACService implements Role-Based Access Control (RBAC)
// It determines what actions different roles are allowed to perform
public class RBACService {

    // Determines if a role is allowed to manage employee records
    public boolean canManageEmployees(Role role) {

        // Only ADMIN and HR roles can manage employees
        return role == Role.ADMIN || role == Role.HR;
    }

    // Determines if a role is allowed to access payroll information
    public boolean canAccessPayroll(Role role) {

        // Only ADMIN and FINANCE roles can access payroll features
        return role == Role.ADMIN || role == Role.FINANCE;
    }

    // Determines if a role is allowed to access system tools
    public boolean canAccessSystemTools(Role role) {

        // Only ADMIN and IT roles can access system maintenance tools
        return role == Role.ADMIN || role == Role.IT;
    }

    // Determines if a role can submit a leave request
    public boolean canSubmitLeave(Role role) {

        // Employees and Admins are allowed to submit leave requests
        return role == Role.EMPLOYEE || role == Role.ADMIN;
    }
}