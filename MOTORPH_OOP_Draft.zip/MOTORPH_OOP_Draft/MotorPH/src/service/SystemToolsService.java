package service;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import dao.CSVHandler;

// SystemToolsService provides diagnostic and monitoring utilities for the system
// It checks file availability, counts records in CSV files, and generates system summaries
public class SystemToolsService {

    // CSVHandler used to read CSV files and count records
    private final CSVHandler csvHandler = new CSVHandler();

    // Returns the status of all system CSV files
    public Map<String, String> getSystemFileStatus() {

        // LinkedHashMap preserves insertion order when displaying results
        Map<String, String> statusMap = new LinkedHashMap<>();

        // Check the status of each system data file
        statusMap.put("Login.csv", getFileStatus("data/Login.csv"));
        statusMap.put("Employee.csv", getFileStatus("data/Employee.csv"));
        statusMap.put("Salary.csv", getFileStatus("data/Salary.csv"));
        statusMap.put("Allowance.csv", getFileStatus("data/Allowance.csv"));
        statusMap.put("TimeTracker.csv", getFileStatus("data/TimeTracker.csv"));
        statusMap.put("LeaveRequests.csv", getFileStatus("data/LeaveRequests.csv"));
        statusMap.put("SalaryLogs.csv", getFileStatus("data/SalaryLogs.csv"));
        statusMap.put("Password_Reset_Requests.csv", getFileStatus("data/Password_Reset_Requests.csv"));
        statusMap.put("LeaveBalances.csv", getFileStatus("data/LeaveBalances.csv"));

        return statusMap;
    }

    // Returns the number of records stored in each system CSV file
    public Map<String, Integer> getSystemRecordCounts() {

        // LinkedHashMap keeps results ordered for display
        Map<String, Integer> countMap = new LinkedHashMap<>();

        // Count records in each CSV file
        countMap.put("Login Records", getRecordCount("data/Login.csv"));
        countMap.put("Employee Records", getRecordCount("data/Employee.csv"));
        countMap.put("Salary Records", getRecordCount("data/Salary.csv"));
        countMap.put("Allowance Records", getRecordCount("data/Allowance.csv"));
        countMap.put("Attendance Records", getRecordCount("data/TimeTracker.csv"));
        countMap.put("Leave Request Records", getRecordCount("data/LeaveRequests.csv"));
        countMap.put("Salary Log Records", getRecordCount("data/SalaryLogs.csv"));
        countMap.put("Password Reset Records", getRecordCount("data/Password_Reset_Requests.csv"));
        countMap.put("Leave Balance Records", getRecordCount("data/LeaveBalances.csv"));

        return countMap;
    }

    // Returns the number of password reset requests in the system
    public int getPasswordResetRequestCount() {
        return getRecordCount("data/Password_Reset_Requests.csv");
    }

    // Generates a formatted system summary showing file status and record counts
    public String getSystemSummary() {

        StringBuilder builder = new StringBuilder();

        builder.append("SYSTEM TOOLS SUMMARY\n");
        builder.append("====================================\n\n");

        // Display file status section
        Map<String, String> fileStatus = getSystemFileStatus();
        builder.append("FILE STATUS\n");
        builder.append("------------------------------------\n");

        for (Map.Entry<String, String> entry : fileStatus.entrySet()) {
            builder.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }

        // Display record counts section
        builder.append("\nRECORD COUNTS\n");
        builder.append("------------------------------------\n");

        Map<String, Integer> recordCounts = getSystemRecordCounts();
        for (Map.Entry<String, Integer> entry : recordCounts.entrySet()) {
            builder.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }

        return builder.toString();
    }

    // Checks the status of a file (Missing, Empty, or Available)
    private String getFileStatus(String path) {

        File file = new File(path);

        // File does not exist
        if (!file.exists()) {
            return "Missing";
        }

        // File exists but contains no data
        if (file.length() == 0) {
            return "Empty";
        }

        // File exists and contains data
        return "Available";
    }

    // Counts the number of data records in a CSV file
    private int getRecordCount(String path) {

        try {

            // Get total rows including header
            int size = csvHandler.readCSV(path).size();

            // Subtract 1 to remove the header row
            return Math.max(0, size - 1);

        } catch (Exception e) {

            // Return 0 if the file cannot be read
            return 0;
        }
    }
}