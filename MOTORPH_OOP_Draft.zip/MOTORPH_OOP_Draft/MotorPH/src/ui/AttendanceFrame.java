package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.AttendanceRecord;
import model.User;
import service.AttendanceService;

// AttendanceFrame is the graphical user interface for managing attendance
// It allows users to record time-in, time-out, and view attendance history
public class AttendanceFrame extends JFrame {

    // Currently logged-in user
    private final User user;

    // Service layer used to process attendance logic
    private final AttendanceService attendanceService;

    // UI components
    private JTextField employeeNumberField;
    private JTextArea outputArea;

    // Constructor that initializes the attendance window
    public AttendanceFrame(User user) {

        // Store the logged-in user
        this.user = user;

        // Initialize the attendance service
        this.attendanceService = new AttendanceService();

        // Configure frame properties
        setTitle("Attendance - " + user.getRole());
        setSize(750, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));

        // Apply UI theme background
        getContentPane().setBackground(UITheme.BACKGROUND);

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Attendance System");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        JLabel subtitleLabel = new JLabel("Record time in, time out, and view attendance history");
        subtitleLabel.setFont(UITheme.BODY_FONT);
        subtitleLabel.setForeground(UITheme.TEXT_LIGHT);

        // Wrap title and subtitle together
        JPanel titleWrap = new JPanel(new GridLayout(2, 1));
        titleWrap.setOpaque(false);
        titleWrap.add(titleLabel);
        titleWrap.add(subtitleLabel);

        headerPanel.add(titleWrap, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Main Content Section
        // ===============================

        JPanel centerPanel = new JPanel(new BorderLayout(12, 12));
        centerPanel.setBackground(UITheme.BACKGROUND);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Employee input form
        JPanel formPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        formPanel.setBackground(UITheme.CARD);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel employeeNumberLabel = new JLabel("Employee Number");
        employeeNumberLabel.setFont(UITheme.BODY_FONT);

        // Pre-fill employee number with the logged-in user's number
        employeeNumberField = new JTextField(user.getEmployeeNumber());
        employeeNumberField.setFont(UITheme.BODY_FONT);

        formPanel.add(employeeNumberLabel);
        formPanel.add(employeeNumberField);

        // ===============================
        // Button Section
        // ===============================

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UITheme.BACKGROUND);

        JButton timeInButton = createButton("Time In");
        JButton timeOutButton = createButton("Time Out");
        JButton viewButton = createButton("View Attendance");

        buttonPanel.add(timeInButton);
        buttonPanel.add(timeOutButton);
        buttonPanel.add(viewButton);

        // ===============================
        // Attendance Display Area
        // ===============================

        outputArea = new JTextArea();
        outputArea.setFont(UITheme.BODY_FONT);
        outputArea.setEditable(false);
        outputArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Attendance Records"));

        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(buttonPanel, BorderLayout.CENTER);
        centerPanel.add(scrollPane, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        // ===============================
        // Button Actions
        // ===============================

        // Time-in button action
        timeInButton.addActionListener(e -> timeIn());

        // Time-out button action
        timeOutButton.addActionListener(e -> timeOut());

        // View attendance history button
        viewButton.addActionListener(e -> viewAttendance());

        setVisible(true);
    }

    // Creates a styled button using the UI theme
    private JButton createButton(String text) {

        JButton button = new JButton(text);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBackground(UITheme.PRIMARY);
        button.setForeground(UITheme.TEXT_LIGHT);
        button.setFocusPainted(false);

        return button;
    }

    // Handles employee time-in
    private void timeIn() {

        // Record time-in through the service layer
        attendanceService.timeIn(employeeNumberField.getText().trim());

        JOptionPane.showMessageDialog(this, "Time in recorded.");

        // Refresh attendance list
        viewAttendance();
    }

    // Handles employee time-out
    private void timeOut() {

        // Record time-out through the service layer
        attendanceService.timeOut(employeeNumberField.getText().trim());

        JOptionPane.showMessageDialog(this, "Time out recorded.");

        // Refresh attendance list
        viewAttendance();
    }

    // Displays attendance history for the employee
    private void viewAttendance() {

        // Retrieve attendance records from the service
        List<AttendanceRecord> records = attendanceService.getAttendance(employeeNumberField.getText().trim());

        outputArea.setText("");

        // Display records in the text area
        for (AttendanceRecord record : records) {
            outputArea.append(
                record.getDate() + " | "
                + record.getTimeIn() + " | "
                + record.getTimeOut() + "\n"
            );
        }
    }
}