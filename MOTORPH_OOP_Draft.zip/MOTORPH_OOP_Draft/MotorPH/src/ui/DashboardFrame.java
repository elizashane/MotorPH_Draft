package ui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.Employee;
import model.User;
import service.EmployeeService;
import service.RBACService;

// DashboardFrame represents the main system dashboard shown after login
// It displays navigation buttons for different system modules
public class DashboardFrame extends JFrame {

    // Logged-in user
    private final User user;

    // Service used for role-based access control
    private final RBACService rbacService;

    // Constructor that initializes the dashboard interface
    public DashboardFrame(User user) {

        this.user = user;
        this.rbacService = new RBACService();

        // Frame configuration
        setTitle("Dashboard - " + user.getRole());
        setSize(850, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        // System logo
        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = new ImageIcon("resources/LogoMPH_(small1).png");
        Image scaledLogo = logoIcon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        logoLabel.setIcon(new ImageIcon(scaledLogo));

        // Dashboard title
        JLabel titleLabel = new JLabel("MotorPH Dashboard");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        // Retrieve employee information for display
        EmployeeService employeeService = new EmployeeService();
        Employee employee = employeeService.findEmployee(user.getEmployeeNumber());

        // Determine display name
        String employeeName;
        if (employee != null) {
            employeeName = employee.getFullName();
        } else {
            employeeName = user.getUsername();
        }

        // Welcome message
        JLabel userLabel = new JLabel("Welcome, " + employeeName + " | Role: " + user.getRole());
        userLabel.setFont(UITheme.BODY_FONT);
        userLabel.setForeground(UITheme.TEXT_LIGHT);

        // Wrap title and welcome message
        JPanel titleWrapper = new JPanel(new BorderLayout());
        titleWrapper.setOpaque(false);
        titleWrapper.add(titleLabel, BorderLayout.NORTH);
        titleWrapper.add(userLabel, BorderLayout.SOUTH);

        headerPanel.add(logoLabel, BorderLayout.WEST);
        headerPanel.add(titleWrapper, BorderLayout.CENTER);

        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Dashboard Buttons Section
        // ===============================

        JPanel centerPanel = new JPanel(new GridLayout(2, 3, 20, 20));
        centerPanel.setBackground(UITheme.BACKGROUND);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        // Create system navigation buttons
        JButton employeeButton = createStyledButton("Employee Management");
        JButton payrollButton = createStyledButton("Payroll");
        JButton attendanceButton = createStyledButton("Attendance");
        JButton leaveButton = createStyledButton("Leave Requests");
        JButton systemButton = createStyledButton("System Tools");
        JButton logoutButton = createStyledButton("Logout");

        centerPanel.add(employeeButton);
        centerPanel.add(payrollButton);
        centerPanel.add(attendanceButton);
        centerPanel.add(leaveButton);
        centerPanel.add(systemButton);
        centerPanel.add(logoutButton);

        add(centerPanel, BorderLayout.CENTER);

        // ===============================
        // Button Actions
        // ===============================

        employeeButton.addActionListener(e -> new EmployeeManagementFrame(user));
        payrollButton.addActionListener(e -> new PayrollFrame(user));
        attendanceButton.addActionListener(e -> new AttendanceFrame(user));
        leaveButton.addActionListener(e -> new LeaveFrame(user));
        systemButton.addActionListener(e -> new ITToolsFrame(user));
        logoutButton.addActionListener(e -> logout());

        // Apply role-based access restrictions
        applyRoleAccess(employeeButton, payrollButton, attendanceButton, leaveButton, systemButton);

        setVisible(true);
    }

    // Creates a styled button using the UI theme
    private JButton createStyledButton(String text) {

        JButton button = new JButton(text);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBackground(UITheme.CARD);
        button.setForeground(UITheme.TEXT_DARK);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(UITheme.BORDER, 1));

        return button;
    }

    // Applies role-based permissions to dashboard buttons
    private void applyRoleAccess(JButton employeeButton,
                                 JButton payrollButton,
                                 JButton attendanceButton,
                                 JButton leaveButton,
                                 JButton systemButton) {

        // Only Admin and HR can manage employees
        employeeButton.setEnabled(rbacService.canManageEmployees(user.getRole()));

        // Only Admin and Finance can access payroll
        payrollButton.setEnabled(rbacService.canAccessPayroll(user.getRole()));

        // Only Admin and IT can access system tools
        systemButton.setEnabled(rbacService.canAccessSystemTools(user.getRole()));

        // Attendance and leave are available to all users
        attendanceButton.setEnabled(true);
        leaveButton.setEnabled(true);
    }

    // Handles logout action
    private void logout() {

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to logout?",
                "Logout",
                JOptionPane.YES_NO_OPTION
        );

        // If confirmed, close dashboard and return to login screen
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame();
        }
    }
}