package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.Employee;
import model.User;
import service.EmployeeService;

// EmployeeManagementFrame is the graphical user interface
// for managing employee records
public class EmployeeManagementFrame extends JFrame {

    // Logged-in user
    private final User user;

    // Service layer used to handle employee-related business logic
    private final EmployeeService employeeService;

    // Input fields for employee information
    private JTextField empNumField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JTextField positionField;
    private JTextField departmentField;
    private JTextField salaryField;
    private JTextField allowanceField;
    private JTextField sssField;
    private JTextField tinField;
    private JTextField pagibigField;
    private JTextField philhealthField;

    // Text area used to display employee records or messages
    private JTextArea outputArea;

    // Constructor that initializes the Employee Management window
    public EmployeeManagementFrame(User user) {
        this.user = user;
        this.employeeService = new EmployeeService();

        // Frame settings
        setTitle("Employee Management - " + user.getRole());
        setSize(900, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(UITheme.BACKGROUND);

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Employee Management");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        JLabel subtitleLabel = new JLabel("Add, update, search, delete, and view employee records");
        subtitleLabel.setFont(UITheme.BODY_FONT);
        subtitleLabel.setForeground(UITheme.TEXT_LIGHT);

        JPanel titleWrap = new JPanel(new GridLayout(2, 1));
        titleWrap.setOpaque(false);
        titleWrap.add(titleLabel);
        titleWrap.add(subtitleLabel);

        headerPanel.add(titleWrap, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Main Content Section
        // ===============================

        JPanel centerPanel = new JPanel(new BorderLayout(12, 12));
        centerPanel.setBackground(UITheme.BACKGROUND);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Form panel for employee input fields
        JPanel formPanel = new JPanel(new GridLayout(12, 2, 10, 10));
        formPanel.setBackground(UITheme.CARD);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        // Initialize text fields
        empNumField = new JTextField();
        firstNameField = new JTextField();
        lastNameField = new JTextField();
        emailField = new JTextField();
        positionField = new JTextField();
        departmentField = new JTextField();
        salaryField = new JTextField();
        allowanceField = new JTextField();
        sssField = new JTextField();
        tinField = new JTextField();
        pagibigField = new JTextField();
        philhealthField = new JTextField();

        // Add labels and text fields to the form panel
        addField(formPanel, "Employee Number", empNumField);
        addField(formPanel, "First Name", firstNameField);
        addField(formPanel, "Last Name", lastNameField);
        addField(formPanel, "Email", emailField);
        addField(formPanel, "Position", positionField);
        addField(formPanel, "Department / Supervisor", departmentField);
        addField(formPanel, "Basic Salary", salaryField);
        addField(formPanel, "Allowance", allowanceField);
        addField(formPanel, "SSS", sssField);
        addField(formPanel, "TIN", tinField);
        addField(formPanel, "Pagibig", pagibigField);
        addField(formPanel, "PhilHealth", philhealthField);

        // ===============================
        // Button Section
        // ===============================

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UITheme.BACKGROUND);

        JButton addButton = createButton("Add");
        JButton updateButton = createButton("Update");
        JButton deleteButton = createButton("Delete");
        JButton searchButton = createButton("Search");
        JButton viewAllButton = createButton("View All");
        JButton clearButton = createButton("Clear");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(viewAllButton);
        buttonPanel.add(clearButton);

        // ===============================
        // Output Display Section
        // ===============================

        outputArea = new JTextArea();
        outputArea.setFont(UITheme.BODY_FONT);
        outputArea.setEditable(false);
        outputArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Employee Records"));

        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(buttonPanel, BorderLayout.CENTER);
        centerPanel.add(scrollPane, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        // ===============================
        // Button Actions
        // ===============================

        addButton.addActionListener(e -> addEmployee());
        updateButton.addActionListener(e -> updateEmployee());
        deleteButton.addActionListener(e -> deleteEmployee());
        searchButton.addActionListener(e -> searchEmployee());
        viewAllButton.addActionListener(e -> viewAllEmployees());
        clearButton.addActionListener(e -> clearFields());

        setVisible(true);
    }

    // Adds a label and text field pair to the form panel
    private void addField(JPanel panel, String label, JTextField field) {
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(UITheme.BODY_FONT);
        panel.add(jLabel);

        field.setFont(UITheme.BODY_FONT);
        panel.add(field);
    }

    // Creates a styled button using the current UI theme
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBackground(UITheme.PRIMARY);
        button.setForeground(UITheme.TEXT_LIGHT);
        button.setFocusPainted(false);
        return button;
    }

    // Builds an Employee object using the values entered in the form fields
    private Employee buildEmployeeFromFields() {
        Employee employee = new Employee();
        employee.setEmployeeNumber(empNumField.getText().trim());
        employee.setFirstName(firstNameField.getText().trim());
        employee.setLastName(lastNameField.getText().trim());
        employee.setEmail(emailField.getText().trim());
        employee.setPosition(positionField.getText().trim());
        employee.setDepartment(departmentField.getText().trim());
        employee.setBasicSalary(parseDouble(salaryField.getText().trim()));
        employee.setAllowance(parseDouble(allowanceField.getText().trim()));
        employee.setSss(sssField.getText().trim());
        employee.setTin(tinField.getText().trim());
        employee.setPagibig(pagibigField.getText().trim());
        employee.setPhilhealth(philhealthField.getText().trim());
        return employee;
    }

    // Handles the add employee action
    private void addEmployee() {
        String result = employeeService.addEmployee(buildEmployeeFromFields());
        JOptionPane.showMessageDialog(this, result);
        viewAllEmployees();
    }

    // Handles the update employee action
    private void updateEmployee() {
        String result = employeeService.updateEmployee(buildEmployeeFromFields());
        JOptionPane.showMessageDialog(this, result);
        viewAllEmployees();
    }

    // Handles the delete employee action
    private void deleteEmployee() {
        String result = employeeService.deleteEmployee(empNumField.getText().trim());
        JOptionPane.showMessageDialog(this, result);
        viewAllEmployees();
    }

    // Searches for one employee using the employee number field
    private void searchEmployee() {
        Employee employee = employeeService.findEmployee(empNumField.getText().trim());

        if (employee == null) {
            JOptionPane.showMessageDialog(this, "Employee not found.");
            return;
        }

        // Populate form fields with the employee's data
        firstNameField.setText(employee.getFirstName());
        lastNameField.setText(employee.getLastName());
        emailField.setText(employee.getEmail());
        positionField.setText(employee.getPosition());
        departmentField.setText(employee.getDepartment());
        salaryField.setText(String.valueOf(employee.getBasicSalary()));
        allowanceField.setText(String.valueOf(employee.getAllowance()));
        sssField.setText(employee.getSss());
        tinField.setText(employee.getTin());
        pagibigField.setText(employee.getPagibig());
        philhealthField.setText(employee.getPhilhealth());

        outputArea.setText("Employee found: " + employee.getFullName());
    }

    // Displays all employee records in the output area
    private void viewAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        outputArea.setText("");

        for (Employee employee : employees) {
            outputArea.append(
                employee.getEmployeeNumber() + " | "
                + employee.getFullName() + " | "
                + employee.getDepartment() + " | "
                + employee.getPosition() + "\n"
            );
        }
    }

    // Clears all input fields and output text
    private void clearFields() {
        empNumField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        positionField.setText("");
        departmentField.setText("");
        salaryField.setText("");
        allowanceField.setText("");
        sssField.setText("");
        tinField.setText("");
        pagibigField.setText("");
        philhealthField.setText("");
        outputArea.setText("");
    }

    // Safely converts text input into a double value
    private double parseDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch (Exception e) {
            return 0.0;
        }
    }
}