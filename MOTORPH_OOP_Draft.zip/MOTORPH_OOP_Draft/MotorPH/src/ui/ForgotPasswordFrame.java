package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import service.PasswordResetService;

// ForgotPasswordFrame provides the interface for users to submit
// a password reset request to the system
public class ForgotPasswordFrame extends JFrame {

    // Service layer responsible for handling password reset requests
    private final PasswordResetService passwordResetService;

    // Input fields for employee number and username
    private JTextField employeeNumberField;
    private JTextField usernameField;

    // Constructor that initializes the forgot password window
    public ForgotPasswordFrame() {

        // Initialize password reset service
        this.passwordResetService = new PasswordResetService();

        // Frame configuration
        setTitle("Forgot Password");
        setSize(450, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(UITheme.BACKGROUND);

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Forgot Password");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Form Section
        // ===============================

        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        formPanel.setBackground(UITheme.CARD);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Initialize input fields
        employeeNumberField = new JTextField();
        usernameField = new JTextField();

        JLabel employeeNumberLabel = new JLabel("Employee Number");
        employeeNumberLabel.setFont(UITheme.BODY_FONT);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(UITheme.BODY_FONT);

        employeeNumberField.setFont(UITheme.BODY_FONT);
        usernameField.setFont(UITheme.BODY_FONT);

        formPanel.add(employeeNumberLabel);
        formPanel.add(employeeNumberField);
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);

        add(formPanel, BorderLayout.CENTER);

        // ===============================
        // Button Section
        // ===============================

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UITheme.BACKGROUND);

        JButton submitButton = new JButton("Submit Request");
        submitButton.setFont(UITheme.BUTTON_FONT);
        submitButton.setBackground(UITheme.PRIMARY);
        submitButton.setForeground(UITheme.TEXT_LIGHT);
        submitButton.setFocusPainted(false);

        buttonPanel.add(submitButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button action to submit reset request
        submitButton.addActionListener(e -> submitRequest());

        setVisible(true);
    }

    // Handles submission of password reset requests
    private void submitRequest() {

        // Send request to the service layer
        String result = passwordResetService.submitRequest(
            employeeNumberField.getText().trim(),
            usernameField.getText().trim()
        );

        // Display result message
        JOptionPane.showMessageDialog(this, result);

        // Close the window if request was successfully submitted
        if (result.toLowerCase().contains("submitted")) {
            dispose();
        }
    }
}