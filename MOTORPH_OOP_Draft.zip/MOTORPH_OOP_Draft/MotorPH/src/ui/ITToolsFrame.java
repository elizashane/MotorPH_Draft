package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.User;
import service.PasswordResetService;
import service.SystemToolsService;

// ITToolsFrame provides system monitoring and maintenance tools
// This module is typically accessible only to IT and Admin roles
public class ITToolsFrame extends JFrame {

    // Logged-in user
    private final User user;

    // Service for retrieving system diagnostics and file status
    private final SystemToolsService systemToolsService;

    // Service for retrieving password reset requests
    private final PasswordResetService passwordResetService;

    // Output display area for system information
    private JTextArea outputArea;

    // Constructor that initializes the IT Tools window
    public ITToolsFrame(User user) {

        this.user = user;
        this.systemToolsService = new SystemToolsService();
        this.passwordResetService = new PasswordResetService();

        // Frame configuration
        setTitle("System Tools - " + user.getRole());
        setSize(850, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(UITheme.BACKGROUND);

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("System Tools Module");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        JLabel subtitleLabel = new JLabel("Available for IT and Admin users");
        subtitleLabel.setFont(UITheme.BODY_FONT);
        subtitleLabel.setForeground(UITheme.TEXT_LIGHT);

        JPanel titleWrap = new JPanel(new BorderLayout());
        titleWrap.setOpaque(false);
        titleWrap.add(titleLabel, BorderLayout.NORTH);
        titleWrap.add(subtitleLabel, BorderLayout.SOUTH);

        headerPanel.add(titleWrap, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Button Section
        // ===============================

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UITheme.BACKGROUND);

        JButton viewSystemStatusButton = createButton("View System Status");
        JButton viewRecordCountsButton = createButton("View Record Counts");
        JButton refreshButton = createButton("Refresh Summary");
        JButton maintenanceButton = createButton("Run Maintenance Check");
        JButton passwordResetButton = createButton("View Password Reset Requests");
        JButton aboutButton = createButton("About System");

        buttonPanel.add(viewSystemStatusButton);
        buttonPanel.add(viewRecordCountsButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(maintenanceButton);
        buttonPanel.add(passwordResetButton);
        buttonPanel.add(aboutButton);

        // ===============================
        // Output Display Section
        // ===============================

        outputArea = new JTextArea();
        outputArea.setFont(UITheme.BODY_FONT);
        outputArea.setEditable(false);
        outputArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("System Output"));

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(UITheme.BACKGROUND);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        centerPanel.add(buttonPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // ===============================
        // Button Actions
        // ===============================

        viewSystemStatusButton.addActionListener(e -> showSystemStatus());
        viewRecordCountsButton.addActionListener(e -> showRecordCounts());
        refreshButton.addActionListener(e -> refreshSummary());
        maintenanceButton.addActionListener(e -> runMaintenanceCheck());
        passwordResetButton.addActionListener(e -> showPasswordResetRequests());
        aboutButton.addActionListener(e -> showAboutSystem());

        // Display summary when frame first loads
        refreshSummary();

        setVisible(true);
    }

    // Creates a styled button using the system UI theme
    private JButton createButton(String text) {

        JButton button = new JButton(text);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBackground(UITheme.PRIMARY);
        button.setForeground(UITheme.TEXT_LIGHT);
        button.setFocusPainted(false);

        return button;
    }

    // Displays the status of all system CSV files
    private void showSystemStatus() {

        StringBuilder builder = new StringBuilder();
        builder.append("SYSTEM FILE STATUS\n");
        builder.append("====================================\n\n");

        systemToolsService.getSystemFileStatus().forEach((file, status) -> {
            builder.append(file).append(": ").append(status).append("\n");
        });

        outputArea.setText(builder.toString());
    }

    // Displays the number of records stored in each CSV file
    private void showRecordCounts() {

        StringBuilder builder = new StringBuilder();
        builder.append("SYSTEM RECORD COUNTS\n");
        builder.append("====================================\n\n");

        systemToolsService.getSystemRecordCounts().forEach((label, count) -> {
            builder.append(label).append(": ").append(count).append("\n");
        });

        outputArea.setText(builder.toString());
    }

    // Refreshes and displays the complete system summary
    private void refreshSummary() {
        outputArea.setText(systemToolsService.getSystemSummary());
    }

    // Simulates a system maintenance check
    private void runMaintenanceCheck() {

        StringBuilder builder = new StringBuilder();
        builder.append("MAINTENANCE CHECK RESULT\n");
        builder.append("====================================\n\n");
        builder.append("Checked all required CSV files.\n");
        builder.append("Validated file availability.\n");
        builder.append("Validated row access through CSV reader.\n");
        builder.append("\nNo destructive changes were made.\n");
        builder.append("Maintenance check completed successfully.");

        outputArea.setText(builder.toString());

        JOptionPane.showMessageDialog(this, "Maintenance check completed.");
    }

    // Displays all submitted password reset requests
    private void showPasswordResetRequests() {

        StringBuilder builder = new StringBuilder();
        builder.append("PASSWORD RESET REQUESTS\n");
        builder.append("====================================\n\n");

        passwordResetService.getAllRequests().forEach(request -> {

            builder.append("Employee #: ").append(request.getEmployeeNumber()).append("\n");
            builder.append("Username: ").append(request.getUsername()).append("\n");
            builder.append("Date: ").append(request.getRequestDate()).append("\n");
            builder.append("Status: ").append(request.getStatus()).append("\n");
            builder.append("------------------------------------\n");
        });

        outputArea.setText(builder.toString());
    }

    // Displays information about the system tools module
    private void showAboutSystem() {

        JOptionPane.showMessageDialog(
                this,
                "MotorPH Payroll System\n\nUser: " + user.getUsername() +
                        "\nRole: " + user.getRole() +
                        "\n\nThis module is intended for system monitoring and password reset request viewing.",
                "About System Tools",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}