package ui;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

// ImagePanel is a custom JPanel used to display a background image
// It automatically scales the image to fit the panel size
public class ImagePanel extends JPanel {

    // Stores the background image
    private final Image backgroundImage;

    // Constructor that loads the image from the specified file path
    public ImagePanel(String imagePath) {

        // Load image using ImageIcon
        ImageIcon icon = new ImageIcon(imagePath);

        // Store the image
        backgroundImage = icon.getImage();

        // Use absolute layout so components can be placed freely
        setLayout(null);
    }

    // Overrides the paintComponent method to draw the background image
    @Override
    protected void paintComponent(Graphics g) {

        // Call the parent method first
        super.paintComponent(g);

        // Draw the background image if it exists
        if (backgroundImage != null) {

            // Scale the image to match the panel size
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}