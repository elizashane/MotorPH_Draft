package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.LeaveRequest;
import model.User;
import service.LeaveService;

// LeaveFrame provides the graphical interface for submitting
// leave requests and viewing leave request history
public class LeaveFrame extends JFrame {

    // Logged-in user
    private final User user;

    // Service responsible for handling leave request operations
    private final LeaveService leaveService;

    // Input fields
    private JTextField employeeNumberField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JTextField reasonField;

    // Output area for displaying leave requests
    private JTextArea outputArea;

    // Constructor that initializes the leave request window
    public LeaveFrame(User user) {

        this.user = user;
        this.leaveService = new LeaveService();

        // Frame configuration
        setTitle("Leave Requests - " + user.getRole());
        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(UITheme.BACKGROUND);

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Leave Request System");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        JLabel subtitleLabel = new JLabel("Submit a leave request and view your leave history");
        subtitleLabel.setFont(UITheme.BODY_FONT);
        subtitleLabel.setForeground(UITheme.TEXT_LIGHT);

        JPanel titleWrap = new JPanel(new GridLayout(2, 1));
        titleWrap.setOpaque(false);
        titleWrap.add(titleLabel);
        titleWrap.add(subtitleLabel);

        headerPanel.add(titleWrap, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Main Content Section
        // ===============================

        JPanel centerPanel = new JPanel(new BorderLayout(12, 12));
        centerPanel.setBackground(UITheme.BACKGROUND);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Form for leave request inputs
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBackground(UITheme.CARD);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        // Initialize input fields
        employeeNumberField = new JTextField(user.getEmployeeNumber());
        startDateField = new JTextField();
        endDateField = new JTextField();
        reasonField = new JTextField();

        // Add labeled fields to the form
        addField(formPanel, "Employee Number", employeeNumberField);
        addField(formPanel, "Start Date (YYYY-MM-DD)", startDateField);
        addField(formPanel, "End Date (YYYY-MM-DD)", endDateField);
        addField(formPanel, "Reason", reasonField);

        // ===============================
        // Button Section
        // ===============================

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UITheme.BACKGROUND);

        JButton submitButton = createButton("Submit Leave");
        JButton viewButton = createButton("View My Requests");
        JButton clearButton = createButton("Clear");

        buttonPanel.add(submitButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(clearButton);

        // ===============================
        // Output Section
        // ===============================

        outputArea = new JTextArea();
        outputArea.setFont(UITheme.BODY_FONT);
        outputArea.setEditable(false);
        outputArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Leave Requests"));

        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(buttonPanel, BorderLayout.CENTER);
        centerPanel.add(scrollPane, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        // Button actions
        submitButton.addActionListener(e -> submitLeave());
        viewButton.addActionListener(e -> viewRequests());
        clearButton.addActionListener(e -> clearFields());

        setVisible(true);
    }

    // Adds a label and text field pair to the form panel
    private void addField(JPanel panel, String label, JTextField field) {

        JLabel jLabel = new JLabel(label);
        jLabel.setFont(UITheme.BODY_FONT);
        panel.add(jLabel);

        field.setFont(UITheme.BODY_FONT);
        panel.add(field);
    }

    // Creates a styled button based on the UI theme
    private JButton createButton(String text) {

        JButton button = new JButton(text);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBackground(UITheme.PRIMARY);
        button.setForeground(UITheme.TEXT_LIGHT);
        button.setFocusPainted(false);

        return button;
    }

    // Handles submission of a leave request
    private void submitLeave() {

        leaveService.submitLeave(
            employeeNumberField.getText().trim(),
            startDateField.getText().trim(),
            endDateField.getText().trim(),
            reasonField.getText().trim()
        );

        JOptionPane.showMessageDialog(this, "Leave request submitted.");

        // Refresh request list after submission
        viewRequests();
    }

    // Displays leave request history for the employee
    private void viewRequests() {

        List<LeaveRequest> requests =
                leaveService.getEmployeeLeaveHistory(employeeNumberField.getText().trim());

        outputArea.setText("");

        for (LeaveRequest request : requests) {

            outputArea.append(
                request.getLeaveId() + " | "
                + request.getStartDate() + " to "
                + request.getEndDate() + " | "
                + request.getReason() + " | "
                + request.getStatus() + "\n"
            );
        }
    }

    // Clears the form fields and output display
    private void clearFields() {

        startDateField.setText("");
        endDateField.setText("");
        reasonField.setText("");
        outputArea.setText("");
    }
}