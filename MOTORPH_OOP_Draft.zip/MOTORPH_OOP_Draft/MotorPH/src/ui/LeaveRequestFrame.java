package ui;

import javax.swing.*;

// LeaveRequestFrame provides a simple interface for submitting a leave request
// Users can enter start and end dates and submit the request
public class LeaveRequestFrame extends JFrame {

    // Constructor that initializes the Leave Request window
    public LeaveRequestFrame(){

        // Set the window title
        setTitle("Leave Request");

        // Set window size
        setSize(400,250);

        // Center the window on the screen
        setLocationRelativeTo(null);

        // Text field for the leave start date
        JTextField start = new JTextField(10);

        // Text field for the leave end date
        JTextField end = new JTextField(10);

        // Button used to submit the leave request
        JButton submit = new JButton("Submit Leave");

        // Panel to hold the form components
        JPanel panel = new JPanel();

        // Add label and input field for start date
        panel.add(new JLabel("Start Date"));
        panel.add(start);

        // Add label and input field for end date
        panel.add(new JLabel("End Date"));
        panel.add(end);

        // Add submit button
        panel.add(submit);

        // Add the panel to the frame
        add(panel);

        // Action triggered when the submit button is clicked
        submit.addActionListener(e ->
                JOptionPane.showMessageDialog(this,"Leave Request Submitted"));

        // Make the window visible
        setVisible(true);
    }
}