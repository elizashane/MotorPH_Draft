package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import model.User;
import service.AuthService;

// LoginFrame provides the graphical login interface for the MotorPH Payroll System
// It allows users to enter their credentials and authenticate through the AuthService
public class LoginFrame extends JFrame {

    // Input fields and buttons used in the login form
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final JButton loginButton;
    private final JButton forgotPasswordButton;
    private final JCheckBox showPasswordCheckBox;

    // Service used to validate login credentials
    private final AuthService authService;

    // Constructor that initializes the login window
    public LoginFrame() {

        authService = new AuthService();

        // Frame configuration
        setTitle("MotorPH Payroll System");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Background image panel
        ImagePanel backgroundPanel = new ImagePanel("resources/MOTORPH_BG.png");
        backgroundPanel.setLayout(new BorderLayout());

        // Transparent overlay for readability
        JPanel overlay = new JPanel(new BorderLayout());
        overlay.setOpaque(true);
        overlay.setBackground(new Color(0, 0, 0, 120));

        // ===============================
        // Header Section
        // ===============================

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 20));
        topPanel.setOpaque(false);

        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = new ImageIcon("resources/MotorPH_Logo2.png");
        Image scaledLogo = logoIcon.getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH);
        logoLabel.setIcon(new ImageIcon(scaledLogo));

        JLabel titleLabel = new JLabel("MotorPH Payroll System");
        titleLabel.setForeground(UITheme.TEXT_LIGHT);
        titleLabel.setFont(UITheme.TITLE_FONT);

        topPanel.add(logoLabel);
        topPanel.add(titleLabel);

        // ===============================
        // Login Card Section
        // ===============================

        JPanel centerWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 30));
        centerWrapper.setOpaque(false);

        JPanel loginCard = new JPanel(new BorderLayout(10, 10));
        loginCard.setPreferredSize(new Dimension(380, 280));
        loginCard.setBackground(UITheme.CARD);
        loginCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel loginTitle = new JLabel("Login", SwingConstants.CENTER);
        loginTitle.setFont(UITheme.SUBTITLE_FONT);
        loginTitle.setForeground(UITheme.TEXT_DARK);

        // ===============================
        // Login Form Section
        // ===============================

        JPanel formPanel = new JPanel(new GridLayout(6, 1, 8, 8));
        formPanel.setBackground(UITheme.CARD);

        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(UITheme.BODY_FONT);

        usernameField = new JTextField();
        usernameField.setFont(UITheme.BODY_FONT);

        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(UITheme.BODY_FONT);

        passwordField = new JPasswordField();
        passwordField.setFont(UITheme.BODY_FONT);

        // Checkbox used to toggle password visibility
        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setBackground(UITheme.CARD);
        showPasswordCheckBox.setFont(UITheme.BODY_FONT);
        showPasswordCheckBox.addActionListener(e -> togglePassword());

        formPanel.add(userLabel);
        formPanel.add(usernameField);
        formPanel.add(passLabel);
        formPanel.add(passwordField);
        formPanel.add(showPasswordCheckBox);
        formPanel.add(new JLabel(""));

        // ===============================
        // Buttons Section
        // ===============================

        loginButton = new JButton("Login");
        loginButton.setFont(UITheme.BUTTON_FONT);
        loginButton.setBackground(UITheme.PRIMARY);
        loginButton.setForeground(UITheme.TEXT_LIGHT);
        loginButton.setFocusPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        forgotPasswordButton = new JButton("Forgot Password");
        forgotPasswordButton.setFont(UITheme.BUTTON_FONT);
        forgotPasswordButton.setBackground(UITheme.CARD);
        forgotPasswordButton.setForeground(UITheme.TEXT_DARK);
        forgotPasswordButton.setFocusPainted(false);
        forgotPasswordButton.setBorder(BorderFactory.createLineBorder(UITheme.BORDER, 1));
        forgotPasswordButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Button actions
        loginButton.addActionListener(e -> login());
        forgotPasswordButton.addActionListener(e -> new ForgotPasswordFrame());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(UITheme.CARD);
        buttonPanel.add(loginButton);
        buttonPanel.add(forgotPasswordButton);

        loginCard.add(loginTitle, BorderLayout.NORTH);
        loginCard.add(formPanel, BorderLayout.CENTER);
        loginCard.add(buttonPanel, BorderLayout.SOUTH);

        centerWrapper.add(loginCard);

        overlay.add(topPanel, BorderLayout.NORTH);
        overlay.add(centerWrapper, BorderLayout.CENTER);

        backgroundPanel.add(overlay, BorderLayout.CENTER);

        setContentPane(backgroundPanel);

        setVisible(true);
    }

    // Toggles password visibility when the checkbox is clicked
    private void togglePassword() {

        if (showPasswordCheckBox.isSelected()) {
            passwordField.setEchoChar((char) 0);
        } else {
            passwordField.setEchoChar('•');
        }
    }

    // Handles the login process
    private void login() {

        // Retrieve input credentials
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        // Authenticate user using AuthService
        User user = authService.login(username, password);

        if (user != null) {

            // Login successful
            JOptionPane.showMessageDialog(this, "Login successful: " + user.getRole());

            // Open dashboard
            new DashboardFrame(user);

            // Close login window
            dispose();

        } else {

            // Invalid credentials
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        }
    }
}