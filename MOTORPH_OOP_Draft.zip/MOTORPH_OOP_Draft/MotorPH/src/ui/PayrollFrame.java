package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.Employee;
import model.PayrollRecord;
import model.User;
import service.EmployeeService;
import service.PayrollService;

// PayrollFrame provides the graphical interface for payroll processing
// It allows authorized users to process payroll, view payslips,
// and generate a simple payroll report
public class PayrollFrame extends JFrame {

    // Logged-in user
    private final User user;

    // Service used for payroll calculations and payroll history retrieval
    private final PayrollService payrollService;

    // Service used to retrieve employee information
    private final EmployeeService employeeService;

    // Input field for employee number
    private JTextField employeeNumberField;

    // Output area for payroll details and reports
    private JTextArea outputArea;

    // Constructor that initializes the Payroll window
    public PayrollFrame(User user) {
        this.user = user;
        this.payrollService = new PayrollService();
        this.employeeService = new EmployeeService();

        // Frame configuration
        setTitle("Payroll System");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(UITheme.BACKGROUND);

        // ===============================
        // Header Section
        // ===============================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Payroll Processing");
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.TEXT_LIGHT);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ===============================
        // Employee Input Section
        // ===============================

        JPanel topPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        topPanel.setBackground(UITheme.BACKGROUND);
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 0, 15));

        JLabel employeeLabel = new JLabel("Employee Number");
        employeeLabel.setFont(UITheme.BODY_FONT);

        employeeNumberField = new JTextField();
        employeeNumberField.setFont(UITheme.BODY_FONT);

        topPanel.add(employeeLabel);
        topPanel.add(employeeNumberField);

        add(topPanel, BorderLayout.BEFORE_FIRST_LINE);

        // ===============================
        // Button Section
        // ===============================

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UITheme.BACKGROUND);

        JButton processPayrollButton = createButton("Process Payroll");
        JButton viewPayslipButton = createButton("View Payslip");
        JButton generateReportButton = createButton("Generate Payroll Report");

        buttonPanel.add(processPayrollButton);
        buttonPanel.add(viewPayslipButton);
        buttonPanel.add(generateReportButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // ===============================
        // Output Section
        // ===============================

        outputArea = new JTextArea();
        outputArea.setFont(UITheme.BODY_FONT);
        outputArea.setEditable(false);
        outputArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Payroll Results"));

        add(scrollPane, BorderLayout.CENTER);

        // ===============================
        // Button Actions
        // ===============================

        processPayrollButton.addActionListener(e -> processPayroll());
        viewPayslipButton.addActionListener(e -> viewPayslip());
        generateReportButton.addActionListener(e -> generateReport());

        setVisible(true);
    }

    // Creates a styled button using the current UI theme
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBackground(UITheme.PRIMARY);
        button.setForeground(UITheme.TEXT_LIGHT);
        button.setFocusPainted(false);
        return button;
    }

    // Formats a two-word name by swapping the word order
    // Example: "John Smith" becomes "Smith John"
    private String formatName(String name) {

        if (name == null || name.isEmpty()) {
            return "";
        }

        String[] parts = name.trim().split("\\s+");

        if (parts.length == 2) {
            return parts[1] + " " + parts[0];
        }

        return name;
    }

    // Processes payroll for the entered employee number
    private void processPayroll() {
        String employeeNumber = employeeNumberField.getText().trim();

        // Validate input
        if (employeeNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an employee number.");
            return;
        }

        // Find employee record
        Employee employee = employeeService.findEmployee(employeeNumber);

        if (employee == null) {
            JOptionPane.showMessageDialog(this, "Employee not found.");
            return;
        }

        // Process payroll using the payroll service
        PayrollRecord payrollRecord = payrollService.processPayroll(employee);

        // Display payroll results in the output area
        outputArea.setText("");
        outputArea.append("PAYROLL PROCESSING RESULT\n");
        outputArea.append("============================================\n\n");
        outputArea.append("Employee Number: " + employee.getEmployeeNumber() + "\n");
        outputArea.append("Employee Name: " + employee.getFullName() + "\n");
        outputArea.append("Position: " + employee.getPosition() + "\n");
        outputArea.append("Supervisor: " + formatName(employee.getDepartment()) + "\n");
        outputArea.append("Basic Salary: " + payrollRecord.getBasicSalary() + "\n");
        outputArea.append("Allowance: " + payrollRecord.getAllowance() + "\n");
        outputArea.append("Gross Salary: " + payrollRecord.getGrossSalary() + "\n");
        outputArea.append("Tax: " + payrollRecord.getTax() + "\n");
        outputArea.append("SSS: " + payrollRecord.getSss() + "\n");
        outputArea.append("PhilHealth: " + payrollRecord.getPhilhealth() + "\n");
        outputArea.append("Pagibig: " + payrollRecord.getPagibig() + "\n");
        outputArea.append("Total Deductions: " + payrollRecord.getTotalDeductions() + "\n");
        outputArea.append("Net Salary: " + payrollRecord.getNetSalary() + "\n");
    }

    // Opens the payslip window for the employee's latest payroll record
    private void viewPayslip() {
        String employeeNumber = employeeNumberField.getText().trim();

        // Validate input
        if (employeeNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an employee number first.");
            return;
        }

        // Retrieve latest payroll record
        PayrollRecord payrollRecord = payrollService.getLatestPayroll(employeeNumber);

        if (payrollRecord == null) {
            JOptionPane.showMessageDialog(this, "No payslip found. Process payroll first.");
            return;
        }

        // Retrieve employee information
        Employee employee = employeeService.findEmployee(employeeNumber);

        if (employee == null) {
            JOptionPane.showMessageDialog(this, "Employee not found.");
            return;
        }

        // Open payslip frame
        new PayslipFrame(employee, payrollRecord);
    }

    // Generates a short payroll report using the employee's latest payroll record
    private void generateReport() {
        String employeeNumber = employeeNumberField.getText().trim();

        // Validate input
        if (employeeNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an employee number.");
            return;
        }

        // Retrieve latest payroll record
        PayrollRecord payrollRecord = payrollService.getLatestPayroll(employeeNumber);

        if (payrollRecord == null) {
            JOptionPane.showMessageDialog(this, "No payroll record found.");
            return;
        }

        // Display report in the output area
        outputArea.setText("");
        outputArea.append("PAYROLL REPORT\n");
        outputArea.append("============================================\n\n");
        outputArea.append("Employee Number: " + payrollRecord.getEmployeeNumber() + "\n");
        outputArea.append("Period Start: " + payrollRecord.getPeriodStart() + "\n");
        outputArea.append("Period End: " + payrollRecord.getPeriodEnd() + "\n");
        outputArea.append("Gross Salary: " + payrollRecord.getGrossSalary() + "\n");
        outputArea.append("Net Salary: " + payrollRecord.getNetSalary() + "\n");
    }
}