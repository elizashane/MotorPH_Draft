package ui;

import java.awt.BorderLayout;

import javax.swing.*;

import model.Employee;
import model.PayrollRecord;
import service.EmployeeService;
import service.PayrollService;

// PayrollProcessingFrame provides a simple interface for processing payroll
// Users can enter an employee number and calculate payroll for that employee
public class PayrollProcessingFrame extends JFrame {

    // Input field for employee number
    private JTextField empField;

    // Text area used to display payroll results
    private JTextArea result;

    // Services used for retrieving employee data and calculating payroll
    private EmployeeService employeeService;
    private PayrollService payrollService;

    // Constructor that initializes the payroll processing window
    public PayrollProcessingFrame(){

        // Initialize service objects
        employeeService = new EmployeeService();
        payrollService = new PayrollService();

        // Frame configuration
        setTitle("Payroll Processing");
        setSize(500,350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===============================
        // Input Section
        // ===============================

        JPanel panel = new JPanel();

        // Label for employee number input
        panel.add(new JLabel("Employee Number"));

        // Text field for entering employee number
        empField = new JTextField(10);
        panel.add(empField);

        // Button to trigger payroll processing
        JButton process = new JButton("Process Payroll");
        panel.add(process);

        // Add input panel to the top of the frame
        add(panel,BorderLayout.NORTH);

        // ===============================
        // Output Section
        // ===============================

        // Text area to display payroll results
        result = new JTextArea();

        // Add scroll pane for better viewing of output
        add(new JScrollPane(result),BorderLayout.CENTER);

        // Button action to process payroll
        process.addActionListener(e -> processPayroll());

        setVisible(true);
    }

    // Processes payroll for the employee entered in the text field
    private void processPayroll(){

        // Retrieve employee information
        Employee emp = employeeService.findEmployee(empField.getText());

        // Validate if employee exists
        if(emp == null){

            JOptionPane.showMessageDialog(this,"Employee not found");
            return;
        }

        // Process payroll using PayrollService
        PayrollRecord payroll = payrollService.processPayroll(emp);

        // Display payroll results in the output text area
        result.setText(
                "Employee: "+emp.getFullName()+"\n"+
                "Gross Salary: "+payroll.getGrossSalary()+"\n"+
                "Net Salary: "+payroll.getNetSalary()
        );
    }
}