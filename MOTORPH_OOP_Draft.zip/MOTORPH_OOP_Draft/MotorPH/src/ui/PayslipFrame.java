package ui;

import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.Employee;
import model.PayrollRecord;

// PayslipFrame displays a formatted payslip for an employee
// It shows earnings, deductions, and net salary for a payroll period
public class PayslipFrame extends JFrame {

    // Constructor that receives employee information and payroll data
    public PayslipFrame(Employee employee, PayrollRecord payroll) {

        // Set window title including the employee's name
        setTitle("Payslip - " + employee.getFullName());

        // Configure frame size and position
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Apply UI theme background
        getContentPane().setBackground(UITheme.BACKGROUND);

        // Text area used to display the formatted payslip
        JTextArea text = new JTextArea();
        text.setFont(UITheme.BODY_FONT);
        text.setEditable(false);

        // Add padding inside the text area
        text.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Build the payslip content using employee and payroll data
        text.setText(
            "MOTORPH PAYSLIP\n" +
            "====================================\n\n" +
            "Employee Number: " + employee.getEmployeeNumber() + "\n" +
            "Employee Name: " + employee.getFullName() + "\n" +
            "Position: " + employee.getPosition() + "\n" +
            "Department / Supervisor: " + employee.getDepartment() + "\n\n" +

            "Pay Period: " + payroll.getPeriodStart() + " to " + payroll.getPeriodEnd() + "\n\n" +

            "EARNINGS\n" +
            "------------------------------------\n" +
            "Basic Salary: " + payroll.getBasicSalary() + "\n" +
            "Allowance: " + payroll.getAllowance() + "\n" +
            "Gross Salary: " + payroll.getGrossSalary() + "\n\n" +

            "DEDUCTIONS\n" +
            "------------------------------------\n" +
            "Tax: " + payroll.getTax() + "\n" +
            "SSS: " + payroll.getSss() + "\n" +
            "PhilHealth: " + payroll.getPhilhealth() + "\n" +
            "Pagibig: " + payroll.getPagibig() + "\n" +
            "Total Deductions: " + payroll.getTotalDeductions() + "\n\n" +

            "NET PAY\n" +
            "------------------------------------\n" +
            "Net Salary: " + payroll.getNetSalary() + "\n"
        );

        // Add scroll functionality to the text area
        add(new JScrollPane(text), BorderLayout.CENTER);

        // Make the frame visible
        setVisible(true);
    }
}