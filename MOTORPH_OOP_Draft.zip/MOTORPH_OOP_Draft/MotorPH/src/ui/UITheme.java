package ui;

import java.awt.Color;
import java.awt.Font;

// UITheme centralizes all colors and fonts used across the application UI
// This ensures a consistent look and makes it easier to update the theme
public class UITheme {

    // ===============================
    // Color Palette
    // ===============================

    // Primary brand color used for headers and buttons
    public static final Color PRIMARY = new Color(190, 20, 35);

    // Darker version of the primary color for emphasis or hover states
    public static final Color PRIMARY_DARK = new Color(120, 10, 20);

    // Main background color for application windows
    public static final Color BACKGROUND = new Color(245, 245, 245);

    // Card background color used for panels and forms
    public static final Color CARD = new Color(255, 255, 255);

    // Dark text color used for most labels and body text
    public static final Color TEXT_DARK = new Color(30, 30, 30);

    // Light text color used for headers and buttons on dark backgrounds
    public static final Color TEXT_LIGHT = new Color(255, 255, 255);

    // Border color used for UI panels and card outlines
    public static final Color BORDER = new Color(210, 210, 210);

    // ===============================
    // Font Styles
    // ===============================

    // Main title font used for headers
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 22);

    // Subtitle font used for section headers
    public static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.BOLD, 16);

    // Standard font used for labels and body text
    public static final Font BODY_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    // Font used for buttons
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);
}